/**
 * Flattens a turn's messages into the ordered list of rows the process timeline renders.
 *
 * Pure module — no React, no DOM, no I/O. Safe to import from the server or a test.
 *
 * This derives everything from data already in the session file. It does not change the
 * `.jsonl` format or the SSE protocol; a reloaded session and a live stream produce the
 * same steps from the same input.
 */

import { isEmptyThinkingBlock, splitFinalAssistantBlocks } from "./message-display";
import type { AgentMessage, AssistantContentBlock, AssistantMessage, ToolResultMessage } from "./types";

export type ProcessStep =
  | {
      kind: "thinking";
      id: string;
      text: string;
      deferred: boolean;
      sessionId?: string;
      entryId?: string;
      blockIndex: number;
      durationSec?: number;
    }
  | { kind: "note"; id: string; title: string; text: string }
  | {
      kind: "tool";
      id: string;
      toolCallId: string;
      toolName: string;
      input: Record<string, unknown>;
      resultText?: string;
      details?: unknown;
      isError: boolean;
      status: "running" | "ok" | "error";
      durationSec?: number;
    }
  | { kind: "bash"; id: string; command: string; output: string; exitCode?: number }
  | { kind: "custom"; id: string; label: string; text: string };

/** Longest a note title may run before it is elided. */
const NOTE_TITLE_MAX = 90;

export interface BuildProcessStepsInput {
  messages: AgentMessage[];
  /** Parallel to `messages`; the `.jsonl` entry id backing each one. */
  entryIds: (string | undefined)[];
  toolResults: Map<string, ToolResultMessage>;
  sessionId?: string;
  isStreaming?: boolean;
}

/**
 * Build the timeline steps for one turn.
 * @param input The turn's messages, their entry ids, and the tool results seen so far
 * @returns Steps in render order
 */
export function buildProcessSteps(input: BuildProcessStepsInput): ProcessStep[] {
  const { messages, entryIds, toolResults, sessionId, isStreaming } = input;
  const steps: ProcessStep[] = [];

  const lastAssistantIndex = findLastAssistantIndex(messages);

  messages.forEach((message, messageIndex) => {
    const entryId = entryIds[messageIndex];
    // `id` must survive a re-render mid-stream or rows remount and lose their open state.
    // Entry ids are stable once written; the positional fallback only applies to a live
    // message that has not been persisted yet, whose position is also stable within a turn.
    const idBase = entryId ?? `m${messageIndex}`;

    switch (message.role) {
      case "assistant":
        steps.push(...assistantSteps({
          message,
          idBase,
          entryId,
          sessionId,
          isStreaming,
          toolResults,
          isFinalAssistant: messageIndex === lastAssistantIndex,
        }));
        break;

      case "bashExecution":
        steps.push({
          kind: "bash",
          id: `${idBase}:0`,
          command: message.command,
          output: message.output,
          exitCode: message.exitCode,
        });
        break;

      case "custom":
        if (message.display) {
          steps.push({
            kind: "custom",
            id: `${idBase}:0`,
            label: message.customType,
            text: contentToText(message.content),
          });
        }
        break;

      // User messages bracket the turn and tool results are folded into their tool call,
      // so neither produces a row of its own.
      default:
        break;
    }
  });

  return steps;
}

/**
 * Turn one assistant message into its steps.
 * @param args The message plus the context needed for ids, timing, and result pairing
 * @returns Steps contributed by this message
 */
function assistantSteps(args: {
  message: AssistantMessage;
  idBase: string;
  entryId?: string;
  sessionId?: string;
  isStreaming?: boolean;
  toolResults: Map<string, ToolResultMessage>;
  isFinalAssistant: boolean;
}): ProcessStep[] {
  const { message, idBase, entryId, sessionId, isStreaming, toolResults, isFinalAssistant } = args;
  const blocks = message.content ?? [];
  const steps: ProcessStep[] = [];

  // The trailing text of the last assistant message is the answer, and the answer is
  // rendered outside the timeline. `splitFinalAssistantBlocks` is the same helper
  // `ChatWindow` uses for that split, so the two cannot disagree about where the answer
  // starts. It is idempotent: a message that is already all process blocks yields itself.
  const answerBlocks = isFinalAssistant
    ? new Set<AssistantContentBlock>(splitFinalAssistantBlocks(message, { isStreaming }).answerBlocks)
    : null;

  blocks.forEach((block, blockIndex) => {
    // `blockIndex` is the index within the stored content array, NOT within the filtered
    // list. The deferred-thinking endpoint is addressed by it
    // (`/api/sessions/[id]/entries/[entryId]/thinking?blockIndex=`), so filtering must
    // never renumber it.
    // `isEmptyThinkingBlock` is declared `block is ThinkingContent`. Used directly in a
    // guard position that predicate narrows `block` to exclude EVERY thinking block from
    // the code below, not just the empty ones, and the `case "thinking"` arm goes dead.
    // The annotation discards the predicate and keeps the runtime filter. Its signature is
    // shared with ChatMinimap via lib/message-display.ts, so it is not ours to change.
    const isEmptyThinking: boolean = isEmptyThinkingBlock(block, { isStreaming });
    if (isEmptyThinking) return;
    if (answerBlocks?.has(block)) return;

    const id = `${idBase}:${blockIndex}`;

    switch (block.type) {
      case "thinking":
        steps.push({
          kind: "thinking",
          id,
          text: block.thinking,
          deferred: block.deferred === true,
          sessionId,
          entryId,
          blockIndex,
        });
        break;

      case "text": {
        const note = toNote(block.text, id);
        if (note) steps.push(note);
        break;
      }

      case "toolCall": {
        const result = toolResults.get(block.toolCallId);
        steps.push({
          kind: "tool",
          id,
          toolCallId: block.toolCallId,
          toolName: block.toolName,
          input: block.input ?? {},
          resultText: result ? contentToText(result.content) : undefined,
          details: result?.details,
          isError: result?.isError === true,
          // No result means the call never returned. While streaming that is genuinely
          // in flight; in a finished session it means the run was cancelled or truncated,
          // and "running" is still the honest label — it never completed.
          status: result ? (result.isError === true ? "error" : "ok") : "running",
          durationSec: toolDuration(message.timestamp, result?.timestamp),
        });
        break;
      }

      // Images inside a process run are not timeline rows.
      default:
        break;
    }
  });

  return steps;
}

/**
 * Build a note step from a mid-process text block.
 * @param text The block's text
 * @param id The step id
 * @returns A note step, or null when the block is blank
 */
function toNote(text: string, id: string): ProcessStep | null {
  const lines = text.split(/\r?\n/);
  const titleIndex = lines.findIndex((line) => line.trim() !== "");
  if (titleIndex === -1) return null;

  const rawTitle = lines[titleIndex].trim();
  const title = rawTitle.length > NOTE_TITLE_MAX ? `${rawTitle.slice(0, NOTE_TITLE_MAX - 1)}…` : rawTitle;
  // Everything after the title line is the expandable body. A short single-line note
  // leaves this empty, which is how the row knows not to draw a chevron.
  const body = lines.slice(titleIndex + 1).join("\n").trim();

  return { kind: "note", id, title, text: body };
}

/**
 * Duration of a tool call, using the formula already in `AssistantMessageView`.
 *
 * The assistant message timestamp is when generation ended, which is when the tools
 * started running; the tool result timestamp is when execution finished.
 * @param messageTimestamp Assistant message timestamp
 * @param resultTimestamp Tool result timestamp
 * @returns Whole seconds, or undefined when the span is unknown or sub-second
 */
function toolDuration(messageTimestamp?: number, resultTimestamp?: number): number | undefined {
  if (!messageTimestamp || !resultTimestamp) return undefined;
  const secs = Math.round((resultTimestamp - messageTimestamp) / 1000);
  return secs > 0 ? secs : undefined;
}

/**
 * Index of the last assistant message, whose trailing text is the turn's answer.
 * @param messages The turn's messages
 * @returns The index, or -1 when the turn has no assistant message
 */
function findLastAssistantIndex(messages: AgentMessage[]): number {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i].role === "assistant") return i;
  }
  return -1;
}

/**
 * Flatten message content into plain text.
 * @param content A string, or the text/image block array used by results and custom messages
 * @returns The concatenated text; image blocks contribute nothing
 */
function contentToText(content: unknown): string {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .filter((block): block is { type: "text"; text: string } =>
      typeof block === "object" && block !== null && (block as { type?: unknown }).type === "text")
    .map((block) => block.text)
    .join("\n");
}

/**
 * Summarize a step list for the collapsed header row.
 * @param steps Steps from `buildProcessSteps`
 * @returns Total step count and how many of them are tool calls
 */
export function summarizeProcessSteps(steps: ProcessStep[]): { stepCount: number; toolCount: number } {
  return {
    stepCount: steps.length,
    toolCount: steps.filter((step) => step.kind === "tool").length,
  };
}
