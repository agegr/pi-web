/**
 * Resolves a raw tool call into what a timeline row should show: a localized label,
 * a verb icon, an argument preview, and an optional right-hand meta string.
 *
 * Pure module — no React, no DOM, no I/O. Safe to import from the server or a test.
 */

import { processCountText, processText } from "./process-ui-text";
import type { Locale } from "./i18n/types";
import type { ToolCallContent } from "./types";

export type ToolIconName = "file" | "edit" | "terminal" | "search" | "globe" | "code" | "generic";

export interface ToolDisplay {
  /** Resolved text, already localized. */
  label: string;
  icon: ToolIconName;
  /** Path / query / command. */
  preview: string;
  /** "16 results", "1 page", "+42 −7". Absent when nothing reliable can be derived. */
  meta?: string;
}

/** How the right-hand meta string is derived for a matched rule. */
type MetaKind = "none" | "lines" | "size" | "diff" | "exitCode" | "results" | "files" | "pages";

interface ToolRule {
  /** Lowercased substrings. Matched with `includes`, never `===`. */
  patterns: string[];
  icon: ToolIconName;
  labelKey: string;
  meta: MetaKind;
}

/**
 * Tool names differ across pi presets and may be renamed by an SDK bump, so matching is
 * by lowercased substring rather than equality.
 *
 * ORDER IS SIGNIFICANT and is not the same as the order of the table in PLAN.md §3.3.
 * Several real tool names match more than one row, and the first match wins:
 *   - `execute_python` matches both "python" and "execute", so the Python rule must be
 *     tested before the shell rule or it renders as "Run command".
 *   - `str_replace_editor` matches both "str_replace" and "edit"; either lands on Edit file,
 *     but the edit rule must precede the read/write rules so it is not read as "Write file".
 *   - `web_search` must not be captured by the fetch rule, so fetch matches on "fetch"
 *     and "browse" only.
 * Reordering this array without re-reading those cases will silently mislabel rows.
 */
const TOOL_RULES: ToolRule[] = [
  { patterns: ["python", "code"], icon: "code", labelKey: "tool.runPython", meta: "none" },
  { patterns: ["str_replace", "apply_patch", "multi_edit", "edit"], icon: "edit", labelKey: "tool.editFile", meta: "diff" },
  { patterns: ["web_fetch", "fetch", "browse"], icon: "globe", labelKey: "tool.fetchUrl", meta: "pages" },
  { patterns: ["web_search", "search", "grep"], icon: "search", labelKey: "tool.search", meta: "results" },
  { patterns: ["glob", "find"], icon: "search", labelKey: "tool.findFiles", meta: "files" },
  { patterns: ["create_file", "write", "create"], icon: "file", labelKey: "tool.writeFile", meta: "size" },
  { patterns: ["read_file", "read", "view"], icon: "file", labelKey: "tool.readFile", meta: "lines" },
  { patterns: ["bash", "shell", "execute", "run_command", "terminal"], icon: "terminal", labelKey: "tool.runCommand", meta: "exitCode" },
];

/**
 * Find the display rule for a tool name.
 * @param toolName Raw tool name as stored in the session file
 * @returns The matching rule, or null when nothing matches
 */
function matchRule(toolName: string): ToolRule | null {
  const name = toolName.toLowerCase();
  for (const rule of TOOL_RULES) {
    if (rule.patterns.some((pattern) => name.includes(pattern))) return rule;
  }
  return null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Count added and removed lines in a unified diff.
 * @param text Patch or diff text
 * @returns Added and removed line counts
 */
export function countDiffStats(text: string): { added: number; removed: number } {
  let added = 0;
  let removed = 0;
  for (const line of text.split(/\r?\n/)) {
    if (line.startsWith("+++") || line.startsWith("---")) continue;
    if (line.startsWith("+")) added += 1;
    else if (line.startsWith("-")) removed += 1;
  }
  return { added, removed };
}

/**
 * Format a byte count for a card or row meta slot.
 * @param bytes Size in bytes
 * @returns A short human-readable size such as "4.2 KB"
 */
export function formatByteSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb < 10 ? kb.toFixed(1) : Math.round(kb)} KB`;
  const mb = kb / 1024;
  return `${mb < 10 ? mb.toFixed(1) : Math.round(mb)} MB`;
}

/**
 * Pull a diff out of a tool result's `details`, mirroring `getResultDiff` in
 * `components/DiffView.tsx` but without requiring a full `ToolResultMessage`.
 * @param details The `details` field of a tool result
 * @returns Patch text, or null when the result carries no diff
 */
function diffTextFromDetails(details: unknown): string | null {
  if (!isRecord(details)) return null;
  if (typeof details.patch === "string") return details.patch;
  if (typeof details.diff === "string") return details.diff;
  return null;
}

/**
 * Derive a countable quantity from a tool result's `details`.
 *
 * Result shapes vary by preset, so this only reads fields whose meaning is unambiguous:
 * an array under a known name, or an explicit numeric count.
 * @param details The `details` field of a tool result
 * @param arrayKeys Field names that would hold the countable collection
 * @returns The count, or null when `details` does not state one
 */
function countFromDetails(details: unknown, arrayKeys: string[]): number | null {
  if (!isRecord(details)) return null;
  for (const key of arrayKeys) {
    const value = details[key];
    if (Array.isArray(value)) return value.length;
  }
  for (const key of ["count", "total", "matchCount", "resultCount"]) {
    const value = details[key];
    if (typeof value === "number" && Number.isFinite(value)) return value;
  }
  return null;
}

/** Non-empty line count — the fallback for list-shaped tool output. */
function countNonEmptyLines(text: string): number {
  return text.split(/\r?\n/).filter((line) => line.trim() !== "").length;
}

/**
 * Read an exit code from a tool result's `details` or the call input.
 * @param details The `details` field of a tool result
 * @param input The tool call input
 * @returns The exit code, or null when none is recorded
 */
function exitCodeFrom(details: unknown, input: Record<string, unknown> | undefined): number | null {
  for (const source of [details, input]) {
    if (!isRecord(source)) continue;
    for (const key of ["exitCode", "exit_code", "code", "status"]) {
      const value = source[key];
      if (typeof value === "number" && Number.isFinite(value)) return value;
    }
  }
  return null;
}

/** The input fields that hold the written body, longest-intent first. */
const CONTENT_FIELDS = ["content", "text", "new_str", "newText", "body"];

/**
 * Compute the meta string for a matched rule.
 * @param kind Which derivation the rule asks for
 * @param context The tool call and its result
 * @returns The meta string, or undefined when nothing reliable is available
 */
function buildMeta(
  kind: MetaKind,
  context: { input?: Record<string, unknown>; resultText?: string; details?: unknown; locale: Locale },
): string | undefined {
  const { input, resultText, details, locale } = context;

  switch (kind) {
    case "diff": {
      const patch = diffTextFromDetails(details) ?? (resultText && /^[+-]|^@@/m.test(resultText) ? resultText : null);
      if (!patch) return undefined;
      const { added, removed } = countDiffStats(patch);
      if (added === 0 && removed === 0) return undefined;
      // U+2212 MINUS SIGN, matching the "+42 −7" spec in PLAN.md §3.1.
      return `+${added} \u2212${removed}`;
    }
    case "lines": {
      if (!resultText) return undefined;
      const lines = resultText.split(/\r?\n/).length;
      return processCountText(locale, lines, "tool.line", "tool.lines");
    }
    case "size": {
      if (!input) return undefined;
      for (const field of CONTENT_FIELDS) {
        const value = input[field];
        if (typeof value === "string") return formatByteSize(byteLength(value));
      }
      return undefined;
    }
    case "exitCode": {
      const code = exitCodeFrom(details, input);
      // A zero exit is the uninteresting case; only surface failures.
      if (code === null || code === 0) return undefined;
      return processText(locale, "tool.exitCode", { code });
    }
    case "results": {
      const count = countFromDetails(details, ["results", "matches", "items"])
        ?? (resultText ? countNonEmptyLines(resultText) : null);
      if (count === null || count === 0) return undefined;
      return processCountText(locale, count, "tool.result", "tool.results");
    }
    case "files": {
      const count = countFromDetails(details, ["files", "paths", "matches"])
        ?? (resultText ? countNonEmptyLines(resultText) : null);
      if (count === null || count === 0) return undefined;
      return processCountText(locale, count, "tool.file", "tool.files");
    }
    case "pages": {
      const count = countFromDetails(details, ["pages", "urls", "documents"])
        ?? (resultText && resultText.trim() !== "" ? 1 : null);
      if (count === null || count === 0) return undefined;
      return processCountText(locale, count, "tool.page", "tool.pages");
    }
    case "none":
    default:
      return undefined;
  }
}

/** Byte length of a string without pulling in Buffer (this runs in the browser too). */
function byteLength(value: string): number {
  if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(value).length;
  return value.length;
}

/**
 * Resolve everything a timeline row needs to render one tool call.
 * @param args The tool call, its result if one has arrived, and the active locale
 * @returns Label, icon, argument preview, and optional meta
 */
export function getToolDisplay(args: {
  toolName: string;
  input?: Record<string, unknown>;
  resultText?: string;
  details?: unknown;
  locale?: Locale;
}): ToolDisplay {
  const { toolName, input, resultText, details } = args;
  const locale: Locale = args.locale ?? "en";

  const preview = getToolPreview({
    type: "toolCall",
    toolCallId: "",
    toolName,
    input: input ?? {},
  });

  const rule = matchRule(toolName);
  if (!rule) {
    // Unknown tool: show the raw name rather than inventing a label.
    return { label: toolName, icon: "generic", preview };
  }

  return {
    label: processText(locale, rule.labelKey),
    icon: rule.icon,
    preview,
    meta: buildMeta(rule.meta, { input, resultText, details, locale }),
  };
}

/**
 * NOTE: copied from `components/MessageView.tsx` @ v0.8.7 (line 1468), not moved.
 * `MessageView.tsx` is deliberately left unmodified by this drop-in bundle (PLAN.md §1.3),
 * so it still owns its own copy and this one is a duplicate. If `MessageView.tsx` is ever
 * replaced or made to export this, delete the copy below and import it from there instead.
 * Kept byte-for-byte identical to the original so the two are easy to diff.
 */
export function getToolPreview(block: ToolCallContent): string {
  const input = block.input;
  if (!input || typeof input !== "object") return "";
  const keys = Object.keys(input);
  if (keys.length === 0) return "";

  // Common tool input patterns
  if ("command" in input) return String(input.command).slice(0, 120);
  if ("path" in input) return String(input.path).slice(0, 120);
  if ("file_path" in input) return String(input.file_path).slice(0, 120);
  if ("pattern" in input) return String(input.pattern).slice(0, 120);
  if ("query" in input) return String(input.query).slice(0, 120);

  const first = input[keys[0]];
  return String(first).slice(0, 120);
}
