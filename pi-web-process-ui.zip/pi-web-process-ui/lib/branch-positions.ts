/**
 * Works out which requests in a session have sibling versions, and where each one sits.
 *
 * pi stores a session as a tree: editing a request and resending it creates a sibling entry
 * under the same parent rather than overwriting the original. `BranchNavigator` already
 * exposes that tree session-wide; this maps it down to individual requests so a turn can
 * show "1/2" next to the prompt it belongs to.
 *
 * Pure module — no React, no DOM, no I/O.
 */

import type { SessionTreeNode } from "./types";

export interface BranchPosition {
  /** 1-based position among siblings, so the label reads "1/2" rather than "0/2". */
  index: number;
  total: number;
  /** Entry ids of every sibling request, in tree order. */
  siblingEntryIds: string[];
}

/** True when a tree node holds a user request rather than a model or tool entry. */
function isRequestNode(node: SessionTreeNode): boolean {
  const role = (node.entry as { message?: { role?: string }; role?: string }).message?.role
    ?? (node.entry as { role?: string }).role;
  return role === "user";
}

/**
 * Map every request entry id to its position among sibling versions.
 *
 * Only sibling groups larger than one produce entries, so a caller can treat a missing key
 * as "this request was never branched" without checking counts.
 * @param tree The session tree, as handed to BranchNavigator
 * @returns Entry id to position, for branched requests only
 */
export function computeBranchPositions(tree: SessionTreeNode[]): Map<string, BranchPosition> {
  const positions = new Map<string, BranchPosition>();

  const visit = (siblings: SessionTreeNode[]): void => {
    const requests = siblings.filter(isRequestNode);
    if (requests.length > 1) {
      const siblingEntryIds = requests.map((node) => node.entry.id);
      requests.forEach((node, i) => {
        positions.set(node.entry.id, { index: i + 1, total: requests.length, siblingEntryIds });
      });
    }
    for (const node of siblings) visit(node.children);
  };

  visit(tree);
  return positions;
}
