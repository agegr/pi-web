/**
 * Strings for the process UI, kept out of `lib/i18n/messages/*.ts` on purpose.
 *
 * This is a deliberate deviation from `docs/i18n.md`, which says translations belong in
 * the locale files. It buys a smaller whole-file replacement surface: the drop-in bundle
 * never has to reproduce two 437-line translation files, so nothing in them can be lost.
 *
 * When this work is upstreamed as real commits, fold `PROCESS_UI_TEXT` into `en.ts` and
 * `zh-CN.ts`, swap `processText(locale, key, params)` for the `t(key, params)` returned by
 * `useI18n()`, and delete this file. The key names below are already `t()`-compatible, so
 * that is a mechanical move.
 *
 * Interpolation is delegated to `interpolateMessage` from `lib/i18n/format.ts`, so
 * `{placeholder}` behaves identically to every other string in the app.
 */

import { interpolateMessage } from "./i18n/format";
import type { Locale, TranslationParams } from "./i18n/types";

/**
 * Every key carries a value for every supported locale. Missing entries fall back to
 * English, then to the key itself — matching `translateMessage()` in `lib/i18n/format.ts`.
 */
export const PROCESS_UI_TEXT: Record<string, Record<Locale, string>> = {
  // — Timeline card ————————————————————————————————————————————————
  "process.title": { en: "Process", "zh-CN": "过程" },
  "process.step": { en: "{count} step", "zh-CN": "{count} 步" },
  "process.steps": { en: "{count} steps", "zh-CN": "{count} 步" },
  "process.tool": { en: "{count} tool", "zh-CN": "{count} 个工具" },
  "process.tools": { en: "{count} tools", "zh-CN": "{count} 个工具" },
  "process.running": { en: "Working", "zh-CN": "处理中" },
  "process.show": { en: "Show process", "zh-CN": "显示过程" },
  "process.hide": { en: "Hide process", "zh-CN": "隐藏过程" },
  "process.modeExpanded": { en: "Process: shown", "zh-CN": "过程：展开" },
  "process.modeCollapsed": { en: "Process: compact", "zh-CN": "过程：精简" },
  "process.modeHidden": { en: "Process: hidden", "zh-CN": "过程：隐藏" },
  "process.thinking": { en: "Thinking", "zh-CN": "思考" },
  "process.loadMore": { en: "Load more", "zh-CN": "加载更多" },

  // — Per-request actions ————————————————————————————————————————————
  "turn.editFromHere": { en: "Edit from here", "zh-CN": "从这里编辑" },
  "turn.newSession": { en: "New session", "zh-CN": "新建会话" },
  "turn.prevBranch": { en: "Previous version", "zh-CN": "上一个版本" },
  "turn.nextBranch": { en: "Next version", "zh-CN": "下一个版本" },
  "process.showRecent": { en: "Show last {count}", "zh-CN": "只看最近 {count} 条" },

  // — Tool rows and the tool panel ——————————————————————————————————
  "tool.request": { en: "Request", "zh-CN": "请求" },
  "tool.response": { en: "Response", "zh-CN": "响应" },
  "tool.running": { en: "Running…", "zh-CN": "运行中…" },
  "tool.truncated": { en: "Truncated", "zh-CN": "已截断" },
  "tool.readFile": { en: "Read file", "zh-CN": "读取文件" },
  "tool.writeFile": { en: "Write file", "zh-CN": "写入文件" },
  "tool.editFile": { en: "Edit file", "zh-CN": "编辑文件" },
  "tool.runCommand": { en: "Run command", "zh-CN": "执行命令" },
  "tool.runPython": { en: "Run Python code", "zh-CN": "运行 Python 代码" },
  "tool.search": { en: "Search", "zh-CN": "搜索" },
  "tool.findFiles": { en: "Find files", "zh-CN": "查找文件" },
  "tool.fetchUrl": { en: "Fetch URLs", "zh-CN": "抓取网页" },
  "tool.result": { en: "{count} result", "zh-CN": "{count} 条结果" },
  "tool.results": { en: "{count} results", "zh-CN": "{count} 条结果" },
  "tool.page": { en: "{count} page", "zh-CN": "{count} 个页面" },
  "tool.pages": { en: "{count} pages", "zh-CN": "{count} 个页面" },
  "tool.file": { en: "{count} file", "zh-CN": "{count} 个文件" },
  "tool.files": { en: "{count} files", "zh-CN": "{count} 个文件" },
  "tool.line": { en: "{count} line", "zh-CN": "{count} 行" },
  "tool.lines": { en: "{count} lines", "zh-CN": "{count} 行" },
  "tool.exitCode": { en: "exit {code}", "zh-CN": "退出码 {code}" },

  // — Output file cards ——————————————————————————————————————————————
  "output.title": { en: "{count} files changed", "zh-CN": "{count} 个文件已更改" },
  "output.created": { en: "New", "zh-CN": "新建" },
  "output.modified": { en: "Changed", "zh-CN": "已修改" },
  "output.view": { en: "View", "zh-CN": "查看" },
  "output.download": { en: "Download", "zh-CN": "下载" },
  "output.copyPath": { en: "Copy path", "zh-CN": "复制路径" },
  "output.unavailable": { en: "Unavailable", "zh-CN": "不可用" },
  "output.more": { en: "+{count} more files", "zh-CN": "另有 {count} 个文件" },
  "output.showFewer": { en: "Show first {count}", "zh-CN": "只看前 {count} 个" },
};

/**
 * Resolve a process-UI string for the active locale.
 * @param locale 当前语言 — the locale from `useI18n()`
 * @param key A key from `PROCESS_UI_TEXT`
 * @param params Optional `{placeholder}` interpolation values
 * @returns The localized string, or the key itself when it is not registered
 */
export function processText(locale: Locale, key: string, params: TranslationParams = {}): string {
  const entry = PROCESS_UI_TEXT[key];
  const message = entry?.[locale] ?? entry?.en;
  if (message === undefined) {
    if (process.env.NODE_ENV !== "production") console.warn(`[process-ui] Missing translation: ${key}`);
    return key;
  }
  return interpolateMessage(message, params);
}

/**
 * Pick the singular or plural key for a count and resolve it.
 *
 * English needs the distinction ("1 page", not "1 pages"); zh-CN maps both keys to the
 * same string, so this stays correct without a full plural-rules dependency.
 * @param locale 当前语言
 * @param count The quantity being described
 * @param singularKey Key used when `count` is exactly 1
 * @param pluralKey Key used otherwise
 * @returns The localized, interpolated string
 */
export function processCountText(locale: Locale, count: number, singularKey: string, pluralKey: string): string {
  return processText(locale, count === 1 ? singularKey : pluralKey, { count });
}
