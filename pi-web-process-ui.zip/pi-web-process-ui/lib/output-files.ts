/**
 * Collects the files a turn created or modified, for the cards shown after the answer.
 *
 * Pure module — no React, no DOM, no I/O. Safe to import from the server or a test.
 *
 * Everything here is derived from tool call inputs and their results. Bash commands are
 * deliberately NOT scanned: parsing `>` redirects, `tee`, `mv`, and heredocs produces more
 * wrong guesses than value, and a wrong card is worse than a missing one.
 */

import { getFileName, getRelativeFilePath, normalizeFilePathSlashes } from "./file-paths";
import { countDiffStats } from "./tool-display";
import type { AgentMessage, ToolResultMessage } from "./types";

export interface OutputFile {
  /** Absolute path. */
  path: string;
  /** Relative to cwd. */
  relPath: string;
  name: string;
  action: "created" | "modified";
  toolCallId: string;
  added?: number;
  removed?: number;
}

/**
 * How many cards the UI renders before collapsing the rest into "+n more files".
 * The collector itself returns everything — dropping data silently in a pure function
 * makes the count in that label impossible to compute.
 */
export const OUTPUT_FILE_CARD_LIMIT = 12;

/** Directory names whose contents are build output or vendored code, never a turn's deliverable. */
const EXCLUDED_SEGMENTS = new Set(["node_modules", ".git", "dist", ".next"]);

/** Input fields that carry the target path, in priority order. */
const PATH_FIELDS = ["path", "file_path", "filename"];

export interface CollectTurnOutputFilesInput {
  messages: AgentMessage[];
  toolResults: Map<string, ToolResultMessage>;
  cwd?: string;
}

/**
 * Collect the files this turn wrote.
 * @param input The turn's messages, the tool results, and the session cwd
 * @returns Deduped output files in first-touched order
 */
export function collectTurnOutputFiles(input: CollectTurnOutputFilesInput): OutputFile[] {
  const { messages, toolResults, cwd } = input;
  const byPath = new Map<string, OutputFile>();

  for (const message of messages) {
    if (message.role !== "assistant") continue;

    for (const block of message.content ?? []) {
      if (block.type !== "toolCall") continue;

      const action = classifyTool(block.toolName);
      if (!action) continue;

      // Only successful calls. A failed edit did not change anything, and showing a card
      // for it would claim work that never landed.
      const result = toolResults.get(block.toolCallId);
      if (!result || result.isError === true) continue;

      const rawPath = readPath(block.input);
      if (!rawPath) continue;

      const absolute = toAbsolutePath(rawPath, cwd);
      if (!absolute || !isWithinCwd(absolute, cwd)) continue;

      const relPath = cwd ? getRelativeFilePath(absolute, cwd) : absolute;
      if (isExcluded(relPath)) continue;

      const stats = diffStatsFor(result);
      const existing = byPath.get(absolute);

      if (!existing) {
        byPath.set(absolute, {
          path: absolute,
          relPath,
          name: getFileName(absolute),
          action,
          toolCallId: block.toolCallId,
          added: stats?.added,
          removed: stats?.removed,
        });
        continue;
      }

      // A file both created and modified in one turn is a new file — "created" wins —
      // and the line counts accumulate across every touch.
      if (action === "created") existing.action = "created";
      if (stats) {
        existing.added = (existing.added ?? 0) + stats.added;
        existing.removed = (existing.removed ?? 0) + stats.removed;
      }
    }
  }

  return [...byPath.values()];
}

/**
 * Decide whether a tool name writes a new file or changes an existing one.
 *
 * Matched by lowercased substring, never `===` — tool names differ across pi presets.
 * Edit patterns are tested first because `str_replace_editor` and `multi_edit` would
 * otherwise be misread by a broader rule.
 * @param toolName Raw tool name
 * @returns The action, or null when the tool does not write files
 */
function classifyTool(toolName: string): OutputFile["action"] | null {
  const name = toolName.toLowerCase();
  if (name.includes("str_replace") || name.includes("apply_patch") || name.includes("multi_edit") || name.includes("edit")) {
    return "modified";
  }
  if (name.includes("create_file") || name.includes("write") || name.includes("create")) {
    return "created";
  }
  return null;
}

/**
 * Read the target path out of a tool call input.
 * @param input The tool call input
 * @returns A non-empty path string, or null
 */
function readPath(input: Record<string, unknown> | undefined): string | null {
  if (!input) return null;
  for (const field of PATH_FIELDS) {
    const value = input[field];
    if (typeof value === "string" && value.trim() !== "") return value.trim();
  }
  return null;
}

/** True when a path is already rooted (POSIX, Windows drive, or UNC). */
function isAbsolutePath(filePath: string): boolean {
  return filePath.startsWith("/") || /^[a-zA-Z]:[\\/]/.test(filePath) || filePath.startsWith("\\\\");
}

/**
 * Resolve a possibly-relative tool path against the session cwd.
 *
 * Uses string logic rather than `node:path` because this module is imported by client
 * components, and because the cwd may use Windows separators while the agent reports
 * POSIX ones.
 * @param rawPath Path as the tool reported it
 * @param cwd Session working directory
 * @returns A normalized absolute path, or null when it cannot be resolved
 */
function toAbsolutePath(rawPath: string, cwd?: string): string | null {
  const normalized = normalizeFilePathSlashes(rawPath);
  if (isAbsolutePath(normalized)) return collapseSegments(normalized);
  if (!cwd) return null;
  const base = normalizeFilePathSlashes(cwd).replace(/\/+$/, "");
  return collapseSegments(`${base}/${normalized}`);
}

/**
 * Resolve `.` and `..` segments without touching the filesystem.
 * @param filePath A slash-normalized path
 * @returns The path with relative segments collapsed
 */
function collapseSegments(filePath: string): string {
  const isUnc = filePath.startsWith("//");
  const leadingSlash = filePath.startsWith("/");
  const parts = filePath.split("/");
  const out: string[] = [];

  for (const part of parts) {
    if (part === "" || part === ".") continue;
    if (part === "..") {
      // Popping past the root is how a `../../etc/passwd` style path escapes; leaving the
      // `..` in place keeps it outside cwd so `isWithinCwd` rejects it.
      if (out.length > 0 && out[out.length - 1] !== "..") out.pop();
      else out.push("..");
      continue;
    }
    out.push(part);
  }

  const joined = out.join("/");
  if (isUnc) return `//${joined}`;
  if (leadingSlash) return `/${joined}`;
  return joined;
}

/**
 * Check that a resolved path really sits under the session cwd.
 * @param absolute A normalized absolute path
 * @param cwd Session working directory
 * @returns True when the path is inside cwd, or when no cwd is known
 */
function isWithinCwd(absolute: string, cwd?: string): boolean {
  if (!cwd) return true;
  const base = collapseSegments(normalizeFilePathSlashes(cwd)).replace(/\/+$/, "");
  if (!base) return true;
  return absolute === base || absolute.startsWith(`${base}/`);
}

/**
 * Reject build output and vendored trees.
 * @param relPath Path relative to cwd
 * @returns True when any segment is an excluded directory
 */
function isExcluded(relPath: string): boolean {
  return normalizeFilePathSlashes(relPath)
    .split("/")
    .some((segment) => EXCLUDED_SEGMENTS.has(segment));
}

/**
 * Read `+n −m` counts from a tool result's diff, when it carries one.
 * @param result The tool result
 * @returns Added and removed line counts, or null
 */
function diffStatsFor(result: ToolResultMessage): { added: number; removed: number } | null {
  const details = result.details;
  if (typeof details !== "object" || details === null || Array.isArray(details)) return null;
  const record = details as Record<string, unknown>;
  const patch = typeof record.patch === "string" ? record.patch : typeof record.diff === "string" ? record.diff : null;
  if (!patch) return null;
  return countDiffStats(patch);
}

export interface SweptFile {
  path: string;
  modifiedMs: number;
  createdMs: number;
  size: number;
}

/**
 * Merge files the filesystem reports as changed into the tool-derived list.
 *
 * Tool calls win on every path they cover: they carry the action and the `+n −m` counts, and
 * they are the record of what the agent meant to do. The sweep only adds paths the tool
 * record never mentioned — which in practice means writes that went through bash.
 *
 * The same directory exclusions apply as for tool-derived paths, so a swept file inside
 * `node_modules` or `dist` is dropped here even if the API returned it.
 * @param toolFiles Files derived from tool calls, in first-touched order
 * @param swept Files the filesystem reports as modified inside the turn window
 * @param input The turn window and cwd used to classify and filter
 * @returns Tool-derived files first, then bash-only writes newest-first
 */
export function mergeSweptOutputFiles(
  toolFiles: OutputFile[],
  swept: SweptFile[],
  input: { cwd?: string; since: number },
): OutputFile[] {
  const known = new Set(toolFiles.map((file) => file.path));
  const extra: OutputFile[] = [];

  for (const hit of swept) {
    const absolute = collapseSegments(normalizeFilePathSlashes(hit.path));
    if (known.has(absolute)) continue;
    if (!isWithinCwd(absolute, input.cwd)) continue;

    const relPath = input.cwd ? getRelativeFilePath(absolute, input.cwd) : absolute;
    if (isExcluded(relPath)) continue;

    known.add(absolute);
    extra.push({
      path: absolute,
      relPath,
      name: getFileName(absolute),
      // birthtime inside the window means the file did not exist before the turn. Where the
      // filesystem does not track it faithfully the value is older, and "modified" is the
      // claim that stays true either way.
      action: hit.createdMs >= input.since ? "created" : "modified",
      toolCallId: "",
    });
  }

  return [...toolFiles, ...extra];
}
