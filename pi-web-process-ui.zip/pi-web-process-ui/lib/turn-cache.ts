/**
 * Caches per-turn derived data so it is computed once per change, not once per render.
 *
 * THE PROBLEM THIS SOLVES
 * `ChatWindow` derives each turn's timeline steps, output files and cost inside its render
 * loop. React re-runs that loop on every state change — a keystroke in the composer, a
 * streamed token, opening a panel — so a session with thirty turns re-walked all thirty
 * turns' messages each time. Worse, each pass produced brand new arrays and objects, so the
 * `memo` on every timeline row saw a changed `step` prop and re-rendered too. The work was
 * quadratic in everything: turns × renders × rows.
 *
 * HOW IT WORKS
 * Two layers. The outer layer is a `WeakMap` keyed on the `messages` array itself. React
 * hands `ChatWindow` a new array whenever the conversation changes, so a changed array is a
 * cache miss by construction — there is no staleness to reason about, and no manual
 * invalidation to forget. The inner layer is a plain `Map` keyed by a per-turn string.
 *
 * Because the outer key is weak, a session's cache is collected as soon as its message array
 * is dropped. Nothing accumulates across sessions.
 *
 * Pure module — no React, no DOM, no I/O.
 */

/** Cache entries per messages array. Bounded so one long session cannot grow without limit. */
const MAX_ENTRIES_PER_ARRAY = 200;

const caches = new WeakMap<object, Map<string, unknown>>();

/**
 * Compute a value once per (owner, key) pair and reuse it on later renders.
 *
 * @param owner The array or object whose identity means "nothing has changed" — normally the
 *   `messages` array. A new identity is a cache miss.
 * @param key Identifies the slice of `owner` being derived, e.g. `steps:3-9`.
 * @param compute Produces the value on a miss. Must be pure: it will not run again until the
 *   owner identity changes.
 * @returns The cached or freshly computed value
 */
export function cachedByOwner<T>(owner: object, key: string, compute: () => T): T {
  let cache = caches.get(owner);
  if (!cache) {
    cache = new Map<string, unknown>();
    caches.set(owner, cache);
  }

  if (cache.has(key)) return cache.get(key) as T;

  const value = compute();

  // Evict oldest-first. Map preserves insertion order, so the first key is the coldest.
  if (cache.size >= MAX_ENTRIES_PER_ARRAY) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
  cache.set(key, value);
  return value;
}

/**
 * Build the cache key for one turn.
 *
 * `isStreaming` is part of the key because it changes what a turn renders: a tool call with
 * no result yet is "running" mid-stream and stays "running" afterwards only because the run
 * never completed. Leaving it out would freeze a turn in its streaming shape.
 *
 * @param kind What is being derived, e.g. `"steps"` or `"files"`
 * @param startIdx First message index of the turn
 * @param endIdx One past the last message index of the turn
 * @param isStreaming Whether the agent is mid-run
 * @returns A key unique within one messages array
 */
export function turnCacheKey(kind: string, startIdx: number, endIdx: number, isStreaming: boolean): string {
  return `${kind}:${startIdx}-${endIdx}:${isStreaming ? "s" : "d"}`;
}
