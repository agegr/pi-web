"use client";

/**
 * The usage and timestamp line for a turn that produced no answer text.
 *
 * `MessageView` bails out at `blocks.length === 0 && !isStreaming && !providerError`
 * (MessageView.tsx:571), so a turn that ends on a tool call renders nothing at all — and the
 * token counts, the cost, and the time go with it. The run still spent tokens and still
 * happened at a time worth showing, so this renders that line on its own.
 *
 * `formatUsage` and `formatTime` below are copied from `components/MessageView.tsx` @ v0.8.7
 * (lines 1485 and 75). They are duplicated rather than imported because this bundle
 * deliberately leaves `MessageView.tsx` unmodified (PLAN.md §1.3) and neither is exported.
 * Kept byte-identical so the two footers can never drift apart visually.
 */

import type { AssistantMessage } from "@/lib/types";

/** Copied from components/MessageView.tsx:75 @ v0.8.7. */
function formatTime(ts?: number): string | null {
  if (!ts) return null;
  const d = new Date(ts);
  const now = new Date();
  const isToday = d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();
  const time = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  if (isToday) return time;
  const date = d.toLocaleDateString([], { month: "short", day: "numeric", year: d.getFullYear() !== now.getFullYear() ? "numeric" : undefined });
  return `${date} ${time}`;
}

/** Copied from components/MessageView.tsx:1485 @ v0.8.7. */
function formatUsage(usage: {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
  cost: { total: number };
}, costOverrideUsd?: number): string {
  const parts = [];
  if (usage.input) parts.push(`${usage.input.toLocaleString()} in`);
  if (usage.output) parts.push(`${usage.output.toLocaleString()} out`);
  if (usage.cacheRead) parts.push(`${usage.cacheRead.toLocaleString()} cache R`);
  if (usage.cacheWrite) parts.push(`${usage.cacheWrite.toLocaleString()} cache W`);
  // Only the cost is swapped for the turn total; the token counts stay per-step, which is
  // what they actually measure.
  const cost = costOverrideUsd ?? usage.cost?.total;
  if (cost) parts.push(`$${cost.toFixed(4)}`);
  return parts.join(" · ");
}

export interface TurnFooterProps {
  /** The turn's final assistant message — the source of the token counts. */
  message: AssistantMessage;
  /**
   * Cost summed across every step of the turn, not just the final one.
   * Token counts describe the last request sent to the model; the cost describes the
   * whole turn, which is the number that actually leaves your account.
   */
  costTotalUsd?: number;
  /** Suppress the timestamp when an earlier row in the same turn already showed it. */
  showTimestamp?: boolean;
}

/**
 * Sum the cost of every assistant message in a turn.
 * @param messages The turn's messages, in order
 * @returns Total USD spent across all steps
 */
export function sumTurnCostUsd(messages: { role: string; usage?: { cost?: { total?: number } } }[]): number {
  let total = 0;
  for (const message of messages) {
    if (message.role !== "assistant") continue;
    const cost = message.usage?.cost?.total;
    if (typeof cost === "number" && Number.isFinite(cost)) total += cost;
  }
  return total;
}

/**
 * Render the usage and timestamp line for a turn with no answer bubble to carry it.
 * @param props The turn's final assistant message
 * @returns The footer, or null when there is nothing to show
 */
export function TurnFooter({ message, costTotalUsd, showTimestamp = true }: TurnFooterProps) {
  const usage = message.usage ? formatUsage(message.usage, costTotalUsd) : "";
  const time = showTimestamp ? formatTime(message.timestamp) : null;
  if (!usage && !time) return null;

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 4, marginBottom: 14 }}>
      {usage && <div style={{ fontSize: 11, color: "var(--text-dim)" }}>{usage}</div>}
      {time && (
        // formatTime compares the timestamp against `new Date()` and formats with the
        // ambient locale, so the server and the browser can legitimately disagree — across a
        // midnight boundary, or when the server locale differs from the user's. React is told
        // to accept the client's value rather than report a hydration mismatch. The same
        // exposure exists in MessageView, which this formatter is copied from.
        <span suppressHydrationWarning style={{ fontSize: 10, color: "var(--text-dim)", marginLeft: "auto" }}>
          {time}
        </span>
      )}
    </div>
  );
}
