"use client";

/**
 * Verb icons for process timeline rows.
 *
 * These are NOT `getFileIcon()` from `components/FileIcons.tsx`. That set is file-type
 * oriented (and since v0.8.7 it is a Catppuccin SVG mask tinted to `--text-dim`), which is
 * the right thing for a file card and the wrong thing for a row that says "Run command".
 * Rows need verbs: read, edit, terminal, search, globe, code.
 *
 * Geometry follows the inline SVGs already in `AppShell.tsx` — a 24×24 viewBox, no fill,
 * `currentColor` stroke, rounded caps and joins — at the 1.6 stroke width the process UI
 * spec calls for, so these sit alongside the existing chrome without looking heavier.
 * Colour is inherited: the row sets `--text-muted`, or the error red, on the wrapper.
 */

import type { ToolIconName } from "@/lib/tool-display";

interface IconProps {
  /** Rendered width and height in px. */
  size?: number;
}

const DEFAULT_SIZE = 16;

/**
 * Shared attributes for every icon in this module.
 * @param size Rendered size in px
 * @returns Props spread onto the `<svg>` element
 */
function svgProps(size: number) {
  return {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.6,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
    focusable: false,
    style: { display: "block", flexShrink: 0 },
  };
}

/** A document — read and write rows. */
export function FileVerbIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
      <path d="M14 3v5h5" />
    </svg>
  );
}

/** A pencil — edit rows. */
export function EditVerbIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <path d="M4 20h4l10-10a2.5 2.5 0 0 0-4-4L4 16z" />
      <path d="M13.5 6.5 17.5 10.5" />
    </svg>
  );
}

/** A prompt and cursor — shell rows. */
export function TerminalVerbIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M7 9l3 3-3 3" />
      <path d="M13 15h4" />
    </svg>
  );
}

/** A magnifier — search and glob rows. */
export function SearchVerbIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <circle cx="11" cy="11" r="6" />
      <path d="M15.5 15.5 20 20" />
    </svg>
  );
}

/** A globe — fetch and browse rows. */
export function GlobeVerbIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18z" />
    </svg>
  );
}

/** Angle brackets — code execution rows. */
export function CodeVerbIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <path d="M9 7l-5 5 5 5" />
      <path d="M15 7l5 5-5 5" />
    </svg>
  );
}

/** A neutral dot-in-square — anything unrecognized. */
export function GenericVerbIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <rect x="4" y="4" width="16" height="16" rx="2" />
      <circle cx="12" cy="12" r="1.6" />
    </svg>
  );
}

/** A small bullet — thinking and note rows, which have no tool verb. */
export function StepDotIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)}>
      <circle cx="12" cy="12" r="2.6" fill="currentColor" stroke="none" />
    </svg>
  );
}

/**
 * The row and header disclosure chevron.
 * @param size Rendered size in px
 * @param open Rotates 90° when true, matching the 12 px chevrons elsewhere in the app
 */
export function ProcessChevronIcon({ size = 12, open = false }: IconProps & { open?: boolean }) {
  return (
    <svg
      {...svgProps(size)}
      style={{
        display: "block",
        flexShrink: 0,
        transform: open ? "rotate(90deg)" : "none",
        transition: "transform 120ms ease",
      }}
    >
      <path d="M9 6l6 6-6 6" />
    </svg>
  );
}

/**
 * The pulsing dot on the row a running tool occupies.
 *
 * The keyframes live in the stylesheet `ProcessTimeline` injects; if that has not mounted
 * the dot simply renders static, which is the correct degradation.
 * @param size Rendered size in px
 */
export function RunningDotIcon({ size = DEFAULT_SIZE }: IconProps) {
  return (
    <svg {...svgProps(size)} style={{ display: "block", flexShrink: 0, color: "var(--accent)" }}>
      <circle cx="12" cy="12" r="3.4" fill="currentColor" stroke="none" className="process-ui-pulse" />
    </svg>
  );
}

/** Maps a `ToolDisplay.icon` name to its component. */
const TOOL_ICONS: Record<ToolIconName, (props: IconProps) => React.ReactElement> = {
  file: FileVerbIcon,
  edit: EditVerbIcon,
  terminal: TerminalVerbIcon,
  search: SearchVerbIcon,
  globe: GlobeVerbIcon,
  code: CodeVerbIcon,
  generic: GenericVerbIcon,
};

/**
 * Render the verb icon for a resolved tool display.
 * @param name The `icon` field from `getToolDisplay()`
 * @param size Rendered size in px
 * @returns The matching icon element
 */
export function ToolVerbIcon({ name, size = DEFAULT_SIZE }: { name: ToolIconName; size?: number }) {
  const Icon = TOOL_ICONS[name] ?? GenericVerbIcon;
  return <Icon size={size} />;
}
