"use client";

/**
 * Right-panel view of one tool call: the Request that went out and the Response that came
 * back, sharing the panel with `FileViewer` via the tab bar.
 *
 * Two things make this read like code instead of a JSON blob:
 *  - Request shows one dominant multi-line string field directly (`code`, `command`,
 *    `content`, `new_str`) when the input has one, and falls back to pretty JSON otherwise.
 *  - Response renders a diff through `components/DiffView.tsx` when the tool is an edit tool
 *    and the result carries a patch.
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import { getResultDiff, isEditToolName, SplitPatchView } from "./DiffView";
import { ToolVerbIcon } from "./ProcessIcons";
import { useI18n } from "@/hooks/useI18n";
import { copyText } from "@/lib/clipboard";
import { processText } from "@/lib/process-ui-text";
import { getToolDisplay } from "@/lib/tool-display";
import type { ProcessStep } from "@/lib/process-steps";
import type { ToolResultMessage } from "@/lib/types";

export type ToolStep = ProcessStep & { kind: "tool" };

/** Response bodies above this are clipped, with a banner saying so. */
const MAX_RESPONSE_BYTES = 200 * 1024;
/** How long the copy buttons stay in their "Copied" state. */
const COPIED_MS = 1500;

/** Input fields that hold the one dominant multi-line value worth showing raw. */
const DOMINANT_FIELDS = ["code", "command", "content", "new_str"];

/**
 * Pick the single field that should be shown as raw text instead of JSON.
 * @param input The tool call input
 * @returns The field's value, or null when no single field dominates
 */
function dominantInputField(input: Record<string, unknown>): string | null {
  for (const field of DOMINANT_FIELDS) {
    const value = input[field];
    if (typeof value === "string" && value.includes("\n")) return value;
  }
  // A lone string field is also clearer raw, even on one line.
  const entries = Object.entries(input);
  if (entries.length === 1 && typeof entries[0][1] === "string") return entries[0][1];
  return null;
}

/**
 * A copy button that confirms for a moment after being pressed.
 * @param text What to place on the clipboard
 */
function CopyButton({ text }: { text: string }) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const timer = setTimeout(() => setCopied(false), COPIED_MS);
    return () => clearTimeout(timer);
  }, [copied]);

  return (
    <button
      type="button"
      onClick={() => { copyText(text).then(() => setCopied(true)).catch(() => {}); }}
      title={t("i18n.copy")}
      style={{
        display: "flex", alignItems: "center", gap: 4,
        padding: "2px 6px", border: "none", borderRadius: 4,
        background: "transparent", color: copied ? "var(--accent)" : "var(--text-dim)",
        cursor: "pointer", fontSize: 11, flexShrink: 0,
      }}
    >
      {copied ? t("i18n.copied") : t("i18n.copy")}
    </button>
  );
}

/**
 * A titled section with a copy button in its header.
 * @param title Section heading
 * @param copyValue Text the copy button places on the clipboard
 * @param children Section body
 */
function PanelSection({ title, copyValue, children }: {
  title: string;
  copyValue?: string;
  children: React.ReactNode;
}) {
  return (
    <div style={{ borderBottom: "1px solid var(--border)", minWidth: 0 }}>
      <div
        style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          gap: 8, padding: "8px 12px", position: "sticky", top: 0, zIndex: 1,
          background: "var(--bg-panel)", borderBottom: "1px solid var(--border)",
        }}
      >
        <span style={{ fontSize: 12, fontWeight: 500, color: "var(--text)" }}>{title}</span>
        {copyValue !== undefined && copyValue !== "" && <CopyButton text={copyValue} />}
      </div>
      <div style={{ padding: "10px 12px", minWidth: 0 }}>{children}</div>
    </div>
  );
}

/** Monospaced block used for request and response bodies. */
function CodeBlock({ text }: { text: string }) {
  return (
    <pre
      style={{
        margin: 0, fontFamily: "var(--font-mono)", fontSize: 12, lineHeight: 1.55,
        whiteSpace: "pre-wrap", overflowWrap: "anywhere", color: "var(--text)",
      }}
    >
      {text}
    </pre>
  );
}

export interface ToolCallPanelProps {
  step: ToolStep;
  onClose: () => void;
}

/**
 * Render the Request/Response view for one tool call.
 * @param props The tool step and a close handler
 */
export function ToolCallPanel({ step, onClose }: ToolCallPanelProps) {
  const { locale, t } = useI18n();

  const display = useMemo(
    () => getToolDisplay({
      toolName: step.toolName,
      input: step.input,
      resultText: step.resultText,
      details: step.details,
      locale,
    }),
    [step, locale],
  );

  const requestRaw = useMemo(() => {
    const dominant = dominantInputField(step.input);
    if (dominant !== null) return dominant;
    try {
      return JSON.stringify(step.input, null, 2);
    } catch {
      return String(step.input);
    }
  }, [step.input]);

  const responseRaw = step.resultText ?? "";
  const truncated = responseRaw.length > MAX_RESPONSE_BYTES;
  const responseText = truncated ? responseRaw.slice(0, MAX_RESPONSE_BYTES) : responseRaw;

  // An edit tool's response is far more useful as a diff than as raw JSON.
  const diff = useMemo(() => {
    if (!isEditToolName(step.toolName)) return null;
    // getResultDiff reads `details`, which is all it needs off a ToolResultMessage.
    return getResultDiff({ role: "toolResult", toolCallId: step.toolCallId, content: [], details: step.details } as ToolResultMessage);
  }, [step.details, step.toolCallId, step.toolName]);

  const handleClose = useCallback(() => onClose(), [onClose]);

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", minWidth: 0, background: "var(--bg)" }}>
      <div
        style={{
          display: "flex", alignItems: "center", gap: 8, flexShrink: 0,
          padding: "0 8px 0 12px", height: 38, borderBottom: "1px solid var(--border)",
        }}
      >
        <span style={{ display: "flex", color: step.isError ? "#f87171" : "var(--text-muted)", flexShrink: 0 }}>
          <ToolVerbIcon name={display.icon} />
        </span>
        <span
          title={step.toolName}
          style={{
            flex: 1, minWidth: 0, fontSize: 13, color: "var(--text)",
            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}
        >
          {display.label}
        </span>
        {step.status === "running" && (
          <span style={{ fontSize: 11, color: "var(--text-dim)", flexShrink: 0 }}>
            {processText(locale, "tool.running")}
          </span>
        )}
        <button
          type="button"
          onClick={handleClose}
          title={t("i18n.close")}
          aria-label={t("i18n.close")}
          style={{
            display: "flex", alignItems: "center", justifyContent: "center",
            width: 24, height: 24, padding: 0, border: "none", borderRadius: 4,
            background: "transparent", color: "var(--text-dim)", cursor: "pointer", flexShrink: 0,
          }}
        >
          <svg width="11" height="11" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
            <line x1="2" y1="2" x2="8" y2="8" />
            <line x1="8" y1="2" x2="2" y2="8" />
          </svg>
        </button>
      </div>

      <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden", minWidth: 0 }}>
        <PanelSection title={processText(locale, "tool.request")} copyValue={requestRaw}>
          <CodeBlock text={requestRaw} />
        </PanelSection>

        <PanelSection title={processText(locale, "tool.response")} copyValue={responseRaw}>
          {step.status === "running" ? (
            <span style={{ fontSize: 12, color: "var(--text-dim)" }}>{processText(locale, "tool.running")}</span>
          ) : diff ? (
            <SplitPatchView text={diff.text} />
          ) : responseText === "" ? (
            <span style={{ fontSize: 12, color: "var(--text-dim)" }}>—</span>
          ) : (
            <CodeBlock text={responseText} />
          )}
          {truncated && (
            <div style={{ marginTop: 8, fontSize: 11, color: "var(--text-dim)" }}>
              {processText(locale, "tool.truncated")}
            </div>
          )}
        </PanelSection>
      </div>
    </div>
  );
}
