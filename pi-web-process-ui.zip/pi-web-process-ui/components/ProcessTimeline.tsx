"use client";

/**
 * The process timeline: one card per turn, replacing the stack of per-message boxes that
 * `ProcessDetailsGroup` used to render.
 *
 * Thinking and notes expand downward, inline. Tool rows call `onOpenToolCall` when the
 * host provides it (Bundle 3 wires that to the right-hand panel); until then they expand
 * inline too, so this bundle is useful on its own rather than a dead end.
 *
 * SCROLL, AND WHY THERE IS NO scrollTop HERE (PLAN.md §3.5)
 * v0.8.7 gave `ChatWindow` two `useLayoutEffect` + `ResizeObserver` loops that own scroll
 * position: one sizes the bottom composer spacer, one converges `promptAnchorSpacerHeight`
 * so the last user message stays put while the agent runs. The anchor loop converges by
 * deliberately excluding its own spacer from the measurement, and any outside writer breaks
 * that. So this component never writes `scrollTop`. It relies on `overflow-anchor` to hold
 * visual position when a row above the fold grows, and its one `scrollIntoView` call is
 * guarded by `!agentRunning`. Rows are never expanded programmatically.
 */

import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MarkdownBody } from "./MarkdownBody";
import { ProcessChevronIcon, RunningDotIcon, StepDotIcon, ToolVerbIcon } from "./ProcessIcons";
import { useI18n } from "@/hooks/useI18n";
import { processCountText, processText } from "@/lib/process-ui-text";
import { getToolDisplay } from "@/lib/tool-display";
import { summarizeProcessSteps, type ProcessStep } from "@/lib/process-steps";
import type { ProcessMode } from "@/hooks/useProcessMode";
import type { Locale } from "@/lib/i18n/types";

/* ------------------------------------------------------------------------- *
 * Injected stylesheet
 * ------------------------------------------------------------------------- */

/**
 * Only the rules that cannot be inline styles live here: `:hover`, the dashed connector,
 * `overflow-anchor`, the pulse keyframes, and the reduced-motion opt-out. Everything else
 * is an inline style, so `app/globals.css` (1,077 lines) stays out of the replacement set.
 */
const PROCESS_UI_CSS = `
.process-ui-row:hover { background: var(--bg-hover); }
.process-ui-row { overflow-anchor: none; }
.process-ui-connector {
  position: absolute;
  left: 19px;
  width: 0;
  border-left: 1px dashed var(--border);
}
.process-ui-body { overflow-anchor: none; }
.process-ui-ghost { opacity: 0; transition: opacity 0.12s; }
.process-ui-ghost:hover, .process-ui-ghost:focus-visible { opacity: 1; }
@keyframes process-ui-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.35; }
}
.process-ui-pulse { animation: process-ui-pulse 1.2s ease-in-out infinite; }
@media (prefers-reduced-motion: reduce) {
  .process-ui-pulse { animation: none; }
  .process-ui-ghost { transition: none; }
}
`;

let stylesInjected = false;

/**
 * Inject the stylesheet once per document.
 *
 * Guarded on both a module flag and the `data-process-ui` attribute, so a hot reload that
 * resets module state does not stack duplicate <style> elements.
 */
function useProcessUiStyles(): void {
  useEffect(() => {
    if (stylesInjected || typeof document === "undefined") return;
    if (document.querySelector("style[data-process-ui]")) {
      stylesInjected = true;
      return;
    }
    stylesInjected = true;
    const el = document.createElement("style");
    el.dataset.processUi = "";
    el.textContent = PROCESS_UI_CSS;
    document.head.appendChild(el);
  }, []);
}

/* ------------------------------------------------------------------------- *
 * Deferred thinking
 * ------------------------------------------------------------------------- */

const MAX_THINKING_CACHE_ENTRIES = 100;
const thinkingContentCache = new Map<string, Promise<string>>();

/**
 * Load a thinking block that was omitted from the session's initial response.
 *
 * NOTE: this mirrors `loadThinkingContent` in `components/MessageView.tsx` @ v0.8.7 (line
 * 28), which is not exported. `MessageView.tsx` is deliberately left unmodified by this
 * bundle (PLAN.md §1.3), so the loader is duplicated here rather than exported from there.
 * Same endpoint, same LRU cache behavior.
 * @param sessionId Session the entry belongs to
 * @param entryId The `.jsonl` entry id
 * @param blockIndex Index of the thinking block within that entry's content array
 * @returns The thinking text
 */
function loadThinkingContent(sessionId: string, entryId: string, blockIndex: number): Promise<string> {
  const key = `${sessionId}:${entryId}:${blockIndex}`;
  const cached = thinkingContentCache.get(key);
  if (cached) {
    thinkingContentCache.delete(key);
    thinkingContentCache.set(key, cached);
    return cached;
  }

  const request = fetch(
    `/api/sessions/${encodeURIComponent(sessionId)}/entries/${encodeURIComponent(entryId)}/thinking?blockIndex=${blockIndex}`,
  ).then(async (response) => {
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json() as { thinking?: unknown };
    if (typeof data.thinking !== "string") throw new Error("Invalid thinking response");
    return data.thinking;
  }).catch((error) => {
    thinkingContentCache.delete(key);
    throw error;
  });

  thinkingContentCache.set(key, request);
  if (thinkingContentCache.size > MAX_THINKING_CACHE_ENTRIES) {
    const oldestKey = thinkingContentCache.keys().next().value;
    if (oldestKey) thinkingContentCache.delete(oldestKey);
  }
  return request;
}

/* ------------------------------------------------------------------------- *
 * Layout constants
 * ------------------------------------------------------------------------- */

const ROW_HEIGHT = 34;
/**
 * Ceiling for an expanded thinking body. Long reasoning would otherwise push the whole
 * conversation down; capping it also stops the row from growing on every streamed chunk,
 * which keeps ChatWindow's prompt-anchor ResizeObserver from having to reconverge.
 */
const THINKING_MAX_HEIGHT = 240;
const ROW_PADDING = "0 12px";
const ERROR_COLOR = "#f87171";
/** Rows rendered before the "load more" affordance, per PLAN.md §12. */
const STEP_WINDOW = 20;

/** How much of the streaming tail to show beside a running row. */
const LIVE_TAIL_CHARS = 90;

/** Tool input fields whose value is the thing actually being generated. */
const LIVE_TOOL_FIELDS = ["content", "code", "command", "new_str", "text", "query", "path"];

/**
 * The text a running step is currently producing, collapsed to one line.
 *
 * A row that only ever shows its label looks frozen while the model streams into it. Showing
 * the tail — not the head — means the newest tokens stay visible as they arrive, which is
 * what makes a long file write or a long thought read as progress rather than a hang.
 * @param step The step being rendered
 * @returns A single-line tail, empty when the step has produced nothing yet
 */
export function liveTailText(step: ProcessStep): string {
  let source = "";
  if (step.kind === "thinking") source = step.text;
  else if (step.kind === "note") source = `${step.title} ${step.text}`;
  else if (step.kind === "bash") source = step.output || step.command;
  else if (step.kind === "custom") source = step.text;
  else if (step.kind === "tool") {
    for (const field of LIVE_TOOL_FIELDS) {
      const value = step.input?.[field];
      if (typeof value === "string" && value !== "") { source = value; break; }
    }
  }

  const collapsed = source.replace(/\s+/g, " ").trim();
  if (collapsed === "") return "";
  return collapsed.length > LIVE_TAIL_CHARS ? `…${collapsed.slice(-LIVE_TAIL_CHARS)}` : collapsed;
}

/**
 * Style for an expanded row body.
 *
 * Thinking is the only kind that gets a ceiling: reasoning can run for hundreds of lines,
 * and letting it grow unbounded both buries the answer and makes the row resize on every
 * streamed chunk. Tool and bash output keep their natural height so a diff stays readable.
 * @param kind The step kind whose body is being rendered
 * @returns Inline style for the body container
 */
export function processBodyStyle(kind: ProcessStep["kind"]): React.CSSProperties {
  const base: React.CSSProperties = { padding: "4px 12px 10px 42px", fontSize: 12, lineHeight: 1.6, minWidth: 0 };
  if (kind !== "thinking") return base;
  return { ...base, maxHeight: THINKING_MAX_HEIGHT, overflowY: "auto", overscrollBehavior: "contain" };
}

/**
 * Decide which steps to render for the current window state.
 * @param steps Every step in the turn
 * @param showAll Whether the user has asked for the full list
 * @returns The visible slice and how many are being withheld
 */
export function visibleStepWindow<T>(steps: T[], showAll: boolean): { visible: T[]; hiddenCount: number } {
  if (showAll || steps.length <= STEP_WINDOW) return { visible: steps, hiddenCount: 0 };
  return { visible: steps.slice(steps.length - STEP_WINDOW), hiddenCount: steps.length - STEP_WINDOW };
}

/**
 * Label for the window toggle: expand to everything, or collapse back to the recent tail.
 * @param locale 当前语言
 * @param hiddenCount How many steps are currently withheld
 * @returns The button label
 */
export function stepWindowToggleLabel(locale: Locale, hiddenCount: number): string {
  return hiddenCount > 0
    ? `${processText(locale, "process.loadMore")} (${hiddenCount})`
    : processText(locale, "process.showRecent", { count: STEP_WINDOW });
}

/**
 * Format a duration for the right-hand meta slot.
 * @param seconds Whole seconds
 * @returns "12s" or "1m 04s"
 */
function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}m ${String(secs).padStart(2, "0")}s`;
}

/**
 * Format elapsed run time for the "Working · 00:12" header.
 * @param seconds Whole seconds
 * @returns "00:12"
 */
function formatClock(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

/* ------------------------------------------------------------------------- *
 * Row
 * ------------------------------------------------------------------------- */

interface RowProps {
  step: ProcessStep;
  isLast: boolean;
  /** True for the one row the model is streaming into right now. */
  isLive: boolean;
  agentRunning: boolean;
  cwd?: string;
  onOpenToolCall?: (step: ProcessStep & { kind: "tool" }) => void;
  onOpenFile?: (filePath: string) => void;
}

/**
 * One timeline row. Memoized because a long session can hold hundreds of them and a
 * streaming update re-renders the card on every chunk.
 */
const ProcessRow = memo(function ProcessRow({
  step, isLast, isLive, agentRunning, cwd, onOpenToolCall, onOpenFile,
}: RowProps) {
  const { locale } = useI18n();
  const [open, setOpen] = useState(false);
  const [deferredText, setDeferredText] = useState<string | null>(null);
  const [deferredError, setDeferredError] = useState(false);
  const rowRef = useRef<HTMLDivElement | null>(null);

  // Resolving a tool means scanning the rule table, counting diff lines and formatting a
  // size. Cheap once, but a streaming turn re-renders the card on every chunk.
  const tool = useMemo(
    () => (step.kind === "tool"
      ? getToolDisplay({
          toolName: step.toolName,
          input: step.input,
          resultText: step.resultText,
          details: step.details,
          locale,
        })
      : null),
    [step, locale],
  );

  // What the row shows, by kind.
  const title = step.kind === "thinking" ? processText(locale, "process.thinking")
    : step.kind === "note" ? step.title
    : step.kind === "bash" ? processText(locale, "tool.runCommand")
    : step.kind === "custom" ? step.label
    : tool?.label ?? "";

  const staticPreview = step.kind === "bash" ? step.command : step.kind === "tool" ? tool?.preview ?? "" : "";
  // While this row is the live one, the streaming tail replaces the static preview so the
  // tokens are visible as they land. Falls back to the static preview before any arrive.
  const preview = isLive ? (liveTailText(step) || staticPreview) : staticPreview;

  const meta = step.kind === "tool"
    ? (step.status === "running" ? processText(locale, "tool.running") : tool?.meta)
    : undefined;

  const duration = (step.kind === "thinking" || step.kind === "tool") ? step.durationSec : undefined;

  // A tool row hands off to the panel when the host offers one; otherwise it expands here.
  const opensPanel = step.kind === "tool" && typeof onOpenToolCall === "function";
  const hasBody = step.kind === "thinking"
    || (step.kind === "note" && step.text !== "")
    || step.kind === "bash"
    || step.kind === "custom"
    || (step.kind === "tool" && !opensPanel);
  const isError = step.kind === "tool" && step.isError;
  const isRunning = step.kind === "tool" && step.status === "running";

  const handleActivate = useCallback(() => {
    if (opensPanel && step.kind === "tool") {
      onOpenToolCall?.(step);
      return;
    }
    if (!hasBody) return;
    setOpen((wasOpen) => {
      const next = !wasOpen;
      // Bringing a row that sits far above the fold back into view is safe only when the
      // agent is idle. While it runs, the prompt-anchor loop owns scroll position and this
      // would fight it. Expansion is always user-initiated, so it never races a stream.
      if (next && !agentRunning) {
        requestAnimationFrame(() => rowRef.current?.scrollIntoView({ block: "nearest" }));
      }
      return next;
    });
  }, [agentRunning, hasBody, onOpenToolCall, opensPanel, step]);

  // Deferred thinking is fetched on first expand, never eagerly.
  useEffect(() => {
    if (!open || step.kind !== "thinking" || !step.deferred) return;
    if (deferredText !== null || !step.sessionId || !step.entryId) return;
    let cancelled = false;
    loadThinkingContent(step.sessionId, step.entryId, step.blockIndex)
      .then((text) => { if (!cancelled) setDeferredText(text); })
      .catch(() => { if (!cancelled) setDeferredError(true); });
    return () => { cancelled = true; };
  }, [open, step, deferredText]);

  const bodyText = step.kind === "thinking"
    ? (step.deferred ? (deferredText ?? (deferredError ? "" : "…")) : step.text)
    : step.kind === "note" ? step.text
    : step.kind === "custom" ? step.text
    : step.kind === "bash" ? step.output
    : step.kind === "tool" ? (step.resultText ?? "") : "";

  return (
    <div style={{ position: "relative" }}>
      {!isLast && <div className="process-ui-connector" style={{ top: ROW_HEIGHT - 6, bottom: 0 }} aria-hidden="true" />}

      <div
        ref={rowRef}
        className="process-ui-row"
        role={hasBody || opensPanel ? "button" : undefined}
        tabIndex={hasBody || opensPanel ? 0 : undefined}
        aria-expanded={hasBody ? open : undefined}
        onClick={hasBody || opensPanel ? handleActivate : undefined}
        onKeyDown={(event) => {
          if (!hasBody && !opensPanel) return;
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            handleActivate();
          }
        }}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          minHeight: ROW_HEIGHT,
          padding: ROW_PADDING,
          cursor: hasBody || opensPanel ? "pointer" : "default",
        }}
      >
        <span style={{ display: "flex", width: 16, color: isError ? ERROR_COLOR : "var(--text-muted)", flexShrink: 0 }}>
          {isRunning ? <RunningDotIcon /> : step.kind === "tool" && tool
            ? <ToolVerbIcon name={tool.icon} />
            : <StepDotIcon />}
        </span>

        <span style={{ fontSize: 13, color: isError ? ERROR_COLOR : "var(--text)", flexShrink: 0 }}>
          {title}
        </span>

        {preview && (
          <span
            title={preview}
            style={{
              flex: 1, minWidth: 0, fontSize: 12, color: "var(--text-dim)",
              fontFamily: "var(--font-mono)", overflow: "hidden",
              textOverflow: "ellipsis", whiteSpace: "nowrap",
            }}
          >
            {preview}
          </span>
        )}
        {!preview && <span style={{ flex: 1, minWidth: 0 }} />}

        {(meta || duration !== undefined) && (
          <span style={{ fontSize: 11, color: "var(--text-dim)", fontVariantNumeric: "tabular-nums", flexShrink: 0 }}>
            {[meta, duration !== undefined ? formatDuration(duration) : null].filter(Boolean).join(" · ")}
          </span>
        )}

        {(hasBody || opensPanel) && (
          <span style={{ display: "flex", color: "var(--text-dim)", flexShrink: 0 }}>
            <ProcessChevronIcon open={hasBody && open} />
          </span>
        )}
      </div>

      {hasBody && open && (
        <div
          className="process-ui-body"
          style={processBodyStyle(step.kind)}
        >
          {deferredError && step.kind === "thinking" ? (
            <span style={{ color: ERROR_COLOR }}>{processText(locale, "tool.truncated")}</span>
          ) : step.kind === "bash" || step.kind === "tool" ? (
            <pre style={{ margin: 0, whiteSpace: "pre-wrap", overflowWrap: "anywhere", fontFamily: "var(--font-mono)", fontSize: 12 }}>
              {bodyText}
            </pre>
          ) : (
            <MarkdownBody cwd={cwd} onOpenFile={onOpenFile}>{bodyText}</MarkdownBody>
          )}
        </div>
      )}
    </div>
  );
});

/* ------------------------------------------------------------------------- *
 * Card
 * ------------------------------------------------------------------------- */

export interface ProcessTimelineProps {
  steps: ProcessStep[];
  mode: ProcessMode;
  onModeChange: (mode: ProcessMode) => void;
  agentRunning?: boolean;
  /** Seconds the current run has been going, for the "Working · 00:12" header. */
  elapsedSec?: number;
  cwd?: string;
  onOpenToolCall?: (step: ProcessStep & { kind: "tool" }) => void;
  onOpenFile?: (filePath: string) => void;
}

/**
 * Render one turn's process as a single card.
 * @param props Steps, the turn's mode, and the host callbacks
 */
export function ProcessTimeline({
  steps, mode, onModeChange, agentRunning = false, elapsedSec,
  cwd, onOpenToolCall, onOpenFile,
}: ProcessTimelineProps) {
  const { locale } = useI18n();
  useProcessUiStyles();
  const [showAll, setShowAll] = useState(false);

  const { stepCount, toolCount } = useMemo(() => summarizeProcessSteps(steps), [steps]);

  const totalSec = useMemo(
    () => steps.reduce((sum, step) => sum + (("durationSec" in step && step.durationSec) || 0), 0),
    [steps],
  );

  const headerText = agentRunning
    ? `${processText(locale, "process.running")} · ${formatClock(elapsedSec ?? totalSec)}`
    : [
        processText(locale, "process.title"),
        processCountText(locale, stepCount, "process.step", "process.steps"),
        toolCount > 0 ? processCountText(locale, toolCount, "process.tool", "process.tools") : null,
        totalSec > 0 ? formatDuration(totalSec) : null,
      ].filter(Boolean).join(" · ");

  if (steps.length === 0) return null;

  // Hidden still shows a live status line: hiding everything mid-run makes the UI look
  // stalled. When idle it leaves a ghost affordance, so a mis-click never looks like data loss.
  if (mode === "hidden") {
    return (
      <div style={{ marginBottom: 14 }}>
        <button
          type="button"
          className={agentRunning ? undefined : "process-ui-ghost"}
          onClick={() => onModeChange("collapsed")}
          title={processText(locale, "process.show")}
          style={{
            display: "flex", alignItems: "center", gap: 8,
            minHeight: 20, padding: "0 2px", border: "none", background: "transparent",
            color: "var(--text-muted)", cursor: "pointer", fontSize: 11, textAlign: "left",
          }}
        >
          {agentRunning ? <RunningDotIcon size={12} /> : null}
          <span>{agentRunning ? headerText : processText(locale, "process.show")}</span>
        </button>
      </div>
    );
  }

  const expanded = mode === "expanded";
  const { visible: visibleSteps, hiddenCount } = visibleStepWindow(steps, showAll);

  return (
    <div
      style={{
        marginBottom: 14,
        border: "1px solid var(--border)",
        borderRadius: 10,
        background: "var(--bg)",
        overflow: "hidden",
        overflowAnchor: "auto",
      }}
    >
      <button
        type="button"
        aria-expanded={expanded}
        onClick={() => onModeChange(expanded ? "collapsed" : "expanded")}
        title={expanded ? processText(locale, "process.hide") : processText(locale, "process.show")}
        style={{
          display: "flex", alignItems: "center", gap: 8,
          width: "100%", height: 34, padding: "0 12px",
          border: "none", background: "transparent",
          color: "var(--text-muted)", cursor: "pointer",
          fontSize: 12, textAlign: "left",
        }}
      >
        <ProcessChevronIcon open={expanded} />
        {agentRunning && <RunningDotIcon size={12} />}
        <span style={{ minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {headerText}
        </span>
      </button>

      {expanded && (
        <div style={{ borderTop: "1px solid var(--border)", position: "relative" }}>
          {(hiddenCount > 0 || (showAll && steps.length > STEP_WINDOW)) && (
            <button
              type="button"
              onClick={() => setShowAll((wasShowingAll) => !wasShowingAll)}
              style={{
                display: "block", width: "100%", padding: "6px 12px",
                border: "none", borderBottom: "1px solid var(--border)", background: "transparent",
                color: "var(--text-dim)", cursor: "pointer", fontSize: 11, textAlign: "left",
              }}
            >
              {stepWindowToggleLabel(locale, hiddenCount)}
            </button>
          )}
          {visibleSteps.map((step, index) => (
            <ProcessRow
              key={step.id}
              step={step}
              isLast={index === visibleSteps.length - 1}
              isLive={agentRunning && index === visibleSteps.length - 1}
              agentRunning={agentRunning}
              cwd={cwd}
              onOpenToolCall={onOpenToolCall}
              onOpenFile={onOpenFile}
            />
          ))}
        </div>
      )}
    </div>
  );
}
