import assert from "node:assert/strict";
import test from "node:test";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createJiti } from "jiti";

const jiti = createJiti(import.meta.url, {
  jsx: { runtime: "automatic" },
  tsconfigPaths: true,
});
const { ProcessTimeline, processBodyStyle, visibleStepWindow, stepWindowToggleLabel, liveTailText } =
  await jiti.import("./ProcessTimeline.tsx");
const { I18nProvider } = await jiti.import("../hooks/useI18n.tsx");

function thinkingSteps(count) {
  return Array.from({ length: count }, (_, i) => ({
    kind: "thinking", id: `t${i}`, text: `reasoning ${i}`, deferred: false, blockIndex: i,
  }));
}

function render(steps, mode = "expanded") {
  return renderToStaticMarkup(
    React.createElement(
      I18nProvider,
      null,
      React.createElement(ProcessTimeline, { steps, mode, onModeChange: () => {} }),
    ),
  );
}

/* ---- thinking body is capped so long reasoning cannot bury the answer ---- */

test("a thinking body is capped at 240px and scrolls", () => {
  const style = processBodyStyle("thinking");
  assert.equal(style.maxHeight, 240);
  assert.equal(style.overflowY, "auto");
  // Keeps a scroll gesture inside the body from chaining to the conversation.
  assert.equal(style.overscrollBehavior, "contain");
});

test("other kinds keep their natural height", () => {
  for (const kind of ["tool", "note", "bash", "custom"]) {
    assert.equal(processBodyStyle(kind).maxHeight, undefined, kind);
    assert.equal(processBodyStyle(kind).overflowY, undefined, kind);
  }
});

test("every body kind keeps the shared padding and type scale", () => {
  for (const kind of ["thinking", "tool", "note"]) {
    assert.equal(processBodyStyle(kind).fontSize, 12, kind);
    assert.equal(processBodyStyle(kind).padding, "4px 12px 10px 42px", kind);
  }
});

/* ---- the step window is a toggle, not a one-way door ---- */

test("short turns show every step and offer no toggle", () => {
  const { visible, hiddenCount } = visibleStepWindow(thinkingSteps(5), false);
  assert.equal(visible.length, 5);
  assert.equal(hiddenCount, 0);
});

test("long turns show the most recent 20 and withhold the rest", () => {
  const steps = thinkingSteps(25);
  const { visible, hiddenCount } = visibleStepWindow(steps, false);
  assert.equal(visible.length, 20);
  assert.equal(hiddenCount, 5);
  // The tail, not the head — the newest work is what a running turn is about.
  assert.equal(visible[visible.length - 1].id, "t24");
  assert.equal(visible[0].id, "t5");
});

test("showAll reveals everything and clears the withheld count", () => {
  const { visible, hiddenCount } = visibleStepWindow(thinkingSteps(25), true);
  assert.equal(visible.length, 25);
  assert.equal(hiddenCount, 0);
});

test("exactly 20 steps needs no toggle", () => {
  const { visible, hiddenCount } = visibleStepWindow(thinkingSteps(20), false);
  assert.equal(visible.length, 20);
  assert.equal(hiddenCount, 0);
});

test("the toggle label flips between expanding and collapsing back", () => {
  assert.equal(stepWindowToggleLabel("en", 5), "Load more (5)");
  // hiddenCount 0 while the list is long means everything is shown — offer the way back.
  assert.equal(stepWindowToggleLabel("en", 0), "Show last 20");
  assert.equal(stepWindowToggleLabel("zh-CN", 5), "加载更多 (5)");
  assert.equal(stepWindowToggleLabel("zh-CN", 0), "只看最近 20 条");
});

test("the toggle round-trips: collapsed -> all -> collapsed", () => {
  const steps = thinkingSteps(25);
  let showAll = false;

  let win = visibleStepWindow(steps, showAll);
  assert.equal(win.visible.length, 20);
  assert.equal(stepWindowToggleLabel("en", win.hiddenCount), "Load more (5)");

  showAll = !showAll;
  win = visibleStepWindow(steps, showAll);
  assert.equal(win.visible.length, 25);
  assert.equal(stepWindowToggleLabel("en", win.hiddenCount), "Show last 20");

  showAll = !showAll;
  win = visibleStepWindow(steps, showAll);
  assert.equal(win.visible.length, 20, "must be able to get back to the recent tail");
});

/* ---- card rendering ---- */

test("a long turn renders the expand toggle", () => {
  assert.ok(render(thinkingSteps(25)).includes("Load more (5)"));
});

test("collapsed shows only the header, hidden shows only the affordance", () => {
  const steps = thinkingSteps(3);
  const collapsed = render(steps, "collapsed");
  assert.ok(collapsed.includes("3 steps"));
  assert.ok(!collapsed.includes("reasoning 0"));

  const hidden = render(steps, "hidden");
  assert.ok(hidden.includes("Show process"));
  assert.ok(!hidden.includes("3 steps"));
});

test("an empty turn renders nothing at all", () => {
  assert.equal(render([]), "");
});

/* ---- the live row shows the tokens as they stream ---- */

test("a running thinking row shows the tail of what is being written", () => {
  const step = { kind: "thinking", id: "t", text: "Saya membaca skill widget", deferred: false, blockIndex: 0 };
  assert.equal(liveTailText(step), "Saya membaca skill widget");
});

test("the tail is shown, not the head, so new tokens stay visible", () => {
  const long = Array.from({ length: 40 }, (_, i) => `kata${i}`).join(" ");
  const tail = liveTailText({ kind: "thinking", id: "t", text: long, deferred: false, blockIndex: 0 });
  assert.ok(tail.startsWith("…"), "elision marks the cut");
  assert.ok(tail.endsWith("kata39"), "the newest text must survive");
  assert.ok(!tail.includes("kata0 "), "the oldest text is the part dropped");
  assert.ok(tail.length <= 91);
});

test("a file write streams its content, not just the path", () => {
  // getToolPreview would return the path here; while the write is running the content is
  // the thing actually arriving token by token.
  const step = {
    kind: "tool", id: "s", toolCallId: "c", toolName: "create_file", status: "running", isError: false,
    input: { path: "docs/PLAN.md", content: "# Rencana\nBaris pertama" },
  };
  assert.equal(liveTailText(step), "# Rencana Baris pertama");
});

test("a running command streams the command text", () => {
  const step = {
    kind: "tool", id: "s", toolCallId: "c", toolName: "bash", status: "running", isError: false,
    input: { command: "npm run build" },
  };
  assert.equal(liveTailText(step), "npm run build");
});

test("newlines collapse so the tail stays on one line", () => {
  const step = { kind: "thinking", id: "t", text: "satu\n\n  dua\ttiga ", deferred: false, blockIndex: 0 };
  assert.equal(liveTailText(step), "satu dua tiga");
});

test("a step that has produced nothing yet yields an empty tail", () => {
  assert.equal(liveTailText({ kind: "thinking", id: "t", text: "", deferred: false, blockIndex: 0 }), "");
  assert.equal(liveTailText({ kind: "tool", id: "s", toolCallId: "c", toolName: "bash", status: "running", isError: false, input: {} }), "");
});
