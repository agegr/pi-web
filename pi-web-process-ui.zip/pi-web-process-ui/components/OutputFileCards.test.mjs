import assert from "node:assert/strict";
import test from "node:test";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createJiti } from "jiti";

const jiti = createJiti(import.meta.url, {
  jsx: { runtime: "automatic" },
  tsconfigPaths: true,
});
const { OutputFileCards, visibleOutputFiles, OUTPUT_FILE_PREVIEW_COUNT } = await jiti.import("./OutputFileCards.tsx");
const { collectTurnOutputFiles } = await jiti.import("../lib/output-files.ts");
const { I18nProvider } = await jiti.import("../hooks/useI18n.tsx");

function file(name, action = "created", extra = {}) {
  return { path: `/w/p/${name}`, relPath: name, name, action, toolCallId: `c-${name}`, ...extra };
}

function render(files, onOpenFile) {
  return renderToStaticMarkup(
    React.createElement(I18nProvider, null,
      React.createElement(OutputFileCards, { files, onOpenFile })),
  );
}

test("a turn that wrote nothing renders nothing", () => {
  assert.equal(render([]), "");
});

test("each file gets its path, action badge and actions", () => {
  const html = render([file("docs/PLAN.md")], () => {});
  assert.ok(html.includes("docs/PLAN.md"));
  assert.ok(html.includes("New"), "created files are badged New");
  assert.ok(html.includes("View"));
  assert.ok(html.includes("Download"));
  assert.ok(html.includes("Copy path"));
});

test("modified files are badged separately from new ones", () => {
  const html = render([file("a.ts", "modified")]);
  assert.ok(html.includes("Changed"));
  assert.ok(!html.includes(">New<"));
});

test("View is omitted when the host cannot open files", () => {
  const html = render([file("a.ts")]);
  assert.ok(!html.includes(">View<"));
  assert.ok(html.includes("Download"), "download still works without a host opener");
});

test("the download link points at the same API the file explorer uses", () => {
  const html = render([file("a b.ts")]);
  assert.ok(html.includes("/api/files/w/p/a%20b.ts?type=download"), html.slice(0, 400));
});

test("line counts render with a real minus sign", () => {
  const html = render([file("a.ts", "modified", { added: 42, removed: 7 })]);
  assert.ok(html.includes("+42"));
  assert.ok(html.includes("\u22127"), "U+2212, not a hyphen");
});

test("a file with no diff stats shows no counts", () => {
  const html = render([file("a.ts")]);
  assert.ok(!html.includes("+0"));
});

test("the header counts every file, including ones folded away", () => {
  const files = Array.from({ length: 9 }, (_, i) => file(`f${i}.ts`));
  assert.ok(render(files).includes("9 files changed"));
});

test("only the first four cards render, the rest sit behind a toggle", () => {
  const files = Array.from({ length: 9 }, (_, i) => file(`f${i}.ts`));
  const html = render(files);
  assert.ok(html.includes("f0.ts"));
  assert.ok(html.includes("f3.ts"));
  assert.ok(!html.includes("f4.ts"), "the fifth is withheld");
  assert.ok(html.includes("+5 more files"));
});

test("four or fewer files need no toggle at all", () => {
  const files = Array.from({ length: OUTPUT_FILE_PREVIEW_COUNT }, (_, i) => file(`f${i}.ts`));
  const html = render(files);
  assert.ok(!html.includes("more files"));
  assert.ok(!html.includes("Show first"));
});

test("the toggle round-trips: four -> all -> four", () => {
  const files = Array.from({ length: 9 }, (_, i) => file(`f${i}.ts`));
  let showAll = false;

  let win = visibleOutputFiles(files, showAll);
  assert.equal(win.visible.length, 4);
  assert.equal(win.hiddenCount, 5);

  showAll = !showAll;
  win = visibleOutputFiles(files, showAll);
  assert.equal(win.visible.length, 9);
  assert.equal(win.hiddenCount, 0, "nothing withheld, so the label flips to Show first 4");

  showAll = !showAll;
  win = visibleOutputFiles(files, showAll);
  assert.equal(win.visible.length, 4, "must be able to get back to the short list");
});

test("the collapse label names the count it returns to", () => {
  assert.equal(OUTPUT_FILE_PREVIEW_COUNT, 4);
});

test("end to end: a real turn's tool calls become cards", () => {
  const CWD = "/w/p";
  const assistant = {
    role: "assistant", provider: "p", model: "m",
    content: [
      { type: "toolCall", toolCallId: "c1", toolName: "create_file", input: { path: `${CWD}/docs/PLAN.md` } },
      { type: "toolCall", toolCallId: "c2", toolName: "str_replace_editor", input: { path: `${CWD}/src/app.ts` } },
      { type: "toolCall", toolCallId: "c3", toolName: "bash", input: { command: "echo hi > sneaky.txt" } },
      { type: "toolCall", toolCallId: "c4", toolName: "create_file", input: { path: `${CWD}/failed.ts` } },
    ],
  };
  const results = new Map([
    ["c1", { role: "toolResult", toolCallId: "c1", content: [] }],
    ["c2", { role: "toolResult", toolCallId: "c2", content: [], details: { patch: "+a\n+b\n-c" } }],
    ["c3", { role: "toolResult", toolCallId: "c3", content: [] }],
    ["c4", { role: "toolResult", toolCallId: "c4", content: [], isError: true }],
  ]);

  const files = collectTurnOutputFiles({ messages: [assistant], toolResults: results, cwd: CWD });
  const html = render(files, () => {});

  assert.ok(html.includes("docs/PLAN.md"));
  assert.ok(html.includes("src/app.ts"));
  assert.ok(html.includes("+2 \u22121"), "edit stats come from the result diff");
  assert.ok(!html.includes("sneaky.txt"), "bash redirects are never scanned");
  assert.ok(!html.includes("failed.ts"), "a failed write claims no deliverable");
  assert.ok(html.includes("2 files changed"));
});

/* ---- one session-wide sweep, filtered per turn ---- */

const swept = [
  { path: "/w/p/turn1.txt", modifiedMs: 1000, createdMs: 1000, size: 1 },
  { path: "/w/p/turn2.txt", modifiedMs: 5000, createdMs: 5000, size: 1 },
  { path: "/w/p/turn3.txt", modifiedMs: 9000, createdMs: 9000, size: 1 },
];

function renderWindowed(files, since, until) {
  return renderToStaticMarkup(
    React.createElement(I18nProvider, null,
      React.createElement(OutputFileCards, { files, cwd: "/w/p", since, until, swept })),
  );
}

test("a turn takes only the swept files inside its own window", () => {
  const html = renderWindowed([], 4000, 6000);
  assert.ok(html.includes("turn2.txt"));
  assert.ok(!html.includes("turn1.txt"), "an earlier turn's file must not leak in");
  assert.ok(!html.includes("turn3.txt"), "nor a later turn's");
});

test("each turn of one session gets its own share of a single sweep", () => {
  assert.ok(renderWindowed([], 500, 1500).includes("turn1.txt"));
  assert.ok(renderWindowed([], 8500, 9500).includes("turn3.txt"));
});

test("a turn with no swept files in range falls back to tool-derived only", () => {
  const html = renderWindowed([file("a.ts")], 20000, 21000);
  assert.ok(html.includes("a.ts"));
  assert.ok(!html.includes("turn1.txt"));
  assert.ok(html.includes("1 files changed"));
});

test("without a window the component shows tool-derived files untouched", () => {
  const html = renderToStaticMarkup(
    React.createElement(I18nProvider, null,
      React.createElement(OutputFileCards, { files: [file("a.ts")], swept })),
  );
  assert.ok(html.includes("a.ts"));
  assert.ok(!html.includes("turn1.txt"), "no window means no sweep is applied");
});
