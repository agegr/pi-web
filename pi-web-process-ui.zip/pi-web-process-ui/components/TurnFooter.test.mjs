import assert from "node:assert/strict";
import test from "node:test";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createJiti } from "jiti";

const jiti = createJiti(import.meta.url, {
  jsx: { runtime: "automatic" },
  tsconfigPaths: true,
});
const { TurnFooter, sumTurnCostUsd } = await jiti.import("./TurnFooter.tsx");
const { MessageView } = await jiti.import("./MessageView.tsx");
const { I18nProvider } = await jiti.import("../hooks/useI18n.tsx");
const { splitFinalAssistantBlocks } = await jiti.import("../lib/message-display.ts");

const USAGE = { input: 123, output: 32, cacheRead: 6400, cacheWrite: 0, cost: { total: 0.0001 } };

/** A turn that ends on a tool call: real work, real cost, no answer text. */
const ENDS_ON_TOOL = {
  role: "assistant",
  provider: "p",
  model: "m",
  timestamp: 1754500000000,
  usage: USAGE,
  content: [
    { type: "thinking", thinking: "check the repo first" },
    { type: "toolCall", toolCallId: "c1", toolName: "bash", input: { command: "ls -la" } },
  ],
};

function render(element) {
  return renderToStaticMarkup(React.createElement(I18nProvider, null, element));
}

test("MessageView renders nothing for a turn with no answer blocks", () => {
  // This is why TurnFooter exists. MessageView.tsx:571 bails on an empty block list, so
  // handing it the answer half of a tool-only turn produces no footer at all.
  const answerOnly = { ...ENDS_ON_TOOL, content: splitFinalAssistantBlocks(ENDS_ON_TOOL).answerBlocks };
  assert.equal(answerOnly.content.length, 0);
  assert.equal(render(React.createElement(MessageView, { message: answerOnly, showTimestamp: true })), "");
});

test("TurnFooter shows tokens, cache and cost", () => {
  const html = render(React.createElement(TurnFooter, { message: ENDS_ON_TOOL }));
  assert.ok(html.includes("123 in"));
  assert.ok(html.includes("32 out"));
  assert.ok(html.includes("6,400 cache R"));
  assert.ok(html.includes("$0.0001"));
});

test("TurnFooter omits zero-valued fields, matching MessageView", () => {
  const html = render(React.createElement(TurnFooter, { message: ENDS_ON_TOOL }));
  // cacheWrite is 0 here, so it must not appear at all.
  assert.ok(!html.includes("cache W"));
});

test("TurnFooter never leaks the process blocks it sits beneath", () => {
  const html = render(React.createElement(TurnFooter, { message: ENDS_ON_TOOL }));
  assert.ok(!html.includes("check the repo first"));
  assert.ok(!html.includes("ls -la"));
});

test("TurnFooter shows a timestamp and can suppress it", () => {
  const withTime = render(React.createElement(TurnFooter, { message: ENDS_ON_TOOL }));
  assert.ok(/\d/.test(withTime.replace(/123|32|6,400|0\.0001/g, "")), "a clock or date should render");

  const withoutTime = render(React.createElement(TurnFooter, { message: ENDS_ON_TOOL, showTimestamp: false }));
  assert.ok(withoutTime.includes("123 in"), "usage survives");
});

test("TurnFooter renders nothing when there is nothing to report", () => {
  const bare = { role: "assistant", provider: "p", model: "m", content: [] };
  assert.equal(render(React.createElement(TurnFooter, { message: bare })), "");
});

test("a turn with usage but no timestamp still renders the usage", () => {
  const noTime = { ...ENDS_ON_TOOL, timestamp: undefined };
  const html = render(React.createElement(TurnFooter, { message: noTime }));
  assert.ok(html.includes("123 in"));
});

/* ---- cost is the whole turn, token counts are the last step ---- */

test("cost sums across every step of the turn", () => {
  const turn = [
    { role: "assistant", usage: { cost: { total: 0.0021 } } },
    { role: "toolResult" },
    { role: "assistant", usage: { cost: { total: 0.0019 } } },
    { role: "assistant", usage: { cost: { total: 0.0009 } } },
  ];
  assert.equal(Number(sumTurnCostUsd(turn).toFixed(4)), 0.0049);
});

test("non-assistant messages and missing costs contribute nothing", () => {
  assert.equal(sumTurnCostUsd([{ role: "user" }, { role: "toolResult" }, { role: "assistant" }]), 0);
  assert.equal(sumTurnCostUsd([]), 0);
});

test("the footer shows last-step tokens with the turn's total cost", () => {
  const html = render(React.createElement(TurnFooter, {
    message: { ...ENDS_ON_TOOL, usage: { input: 104, output: 653, cacheRead: 22848, cacheWrite: 0, cost: { total: 0.0021 } } },
    costTotalUsd: 0.0049,
  }));
  assert.ok(html.includes("104 in"));
  assert.ok(html.includes("653 out"));
  assert.ok(html.includes("22,848 cache R"));
  // The turn total, not this one step's 0.0021.
  assert.ok(html.includes("$0.0049"), "cost must be the turn total");
  assert.ok(!html.includes("$0.0021"));
});

test("without an override the footer falls back to the step's own cost", () => {
  const html = render(React.createElement(TurnFooter, { message: ENDS_ON_TOOL }));
  assert.ok(html.includes("$0.0001"));
});
