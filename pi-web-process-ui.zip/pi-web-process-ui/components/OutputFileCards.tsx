"use client";

/**
 * The files a turn produced, shown as cards after the answer.
 *
 * The point is that a turn's deliverables should be reachable without scrolling back through
 * the process to find which tool call wrote what. `collectTurnOutputFiles` derives the list
 * from tool inputs and their results — it never scans bash commands, so a card is only ever
 * shown for a write that actually succeeded.
 *
 * Nothing here fetches. View delegates to the host's `onOpenFile`, which reuses the file tab
 * the explorer already opens; Download is a plain link to the same `/api/files` route
 * `FileExplorer` uses.
 */

import { useMemo, useState } from "react";
import { useI18n } from "@/hooks/useI18n";
import { encodeFilePathForApi } from "@/lib/file-paths";
import { processText } from "@/lib/process-ui-text";
import { mergeSweptOutputFiles, type OutputFile, type SweptFile } from "@/lib/output-files";

const COPIED_MS = 1500;

/**
 * How many cards show before the rest are folded away.
 *
 * Four, not the twelve `OUTPUT_FILE_CARD_LIMIT` allows: the cards sit between the answer and
 * the usage line, and a dozen of them push the answer off screen — which is the opposite of
 * what a summary of deliverables is for.
 */
export const OUTPUT_FILE_PREVIEW_COUNT = 4;

/**
 * Split the file list into what is shown and what is withheld.
 * @param files Every file the turn wrote
 * @param showAll Whether the user has asked for the full list
 * @returns The visible slice and the withheld count
 */
export function visibleOutputFiles<T>(files: T[], showAll: boolean): { visible: T[]; hiddenCount: number } {
  if (showAll || files.length <= OUTPUT_FILE_PREVIEW_COUNT) return { visible: files, hiddenCount: 0 };
  return {
    visible: files.slice(0, OUTPUT_FILE_PREVIEW_COUNT),
    hiddenCount: files.length - OUTPUT_FILE_PREVIEW_COUNT,
  };
}

export interface OutputFileCardsProps {
  files: OutputFile[];
  onOpenFile?: (filePath: string) => void;
  cwd?: string;
  /** This turn's window. Used to pick this turn's share of the session-wide sweep. */
  since?: number;
  until?: number;
  /**
   * Files the filesystem reports as changed, swept ONCE for the whole session by ChatWindow
   * and shared across every turn.
   *
   * Sweeping per turn meant one full tree walk per turn, so opening a long session paid that
   * cost N times over and the cards took seconds to appear. One walk, filtered N ways, is the
   * same information for a fraction of the work.
   */
  swept?: SweptFile[];
}

/**
 * Copy a path to the clipboard, falling back when the API is unavailable.
 * @param text The path to copy
 * @returns Whether the copy succeeded
 */
async function copyPath(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

/** One file's card. */
function FileCard({ file, onOpenFile }: { file: OutputFile; onOpenFile?: (filePath: string) => void }) {
  const { locale } = useI18n();
  const [copied, setCopied] = useState(false);

  const created = file.action === "created";
  const hasDiff = typeof file.added === "number" || typeof file.removed === "number";

  return (
    <div
      style={{
        display: "flex", alignItems: "center", gap: 8, minWidth: 0,
        padding: "6px 10px", border: "1px solid var(--border)", borderRadius: 8,
        background: "var(--bg)",
      }}
    >
      <span
        style={{
          flexShrink: 0, padding: "1px 6px", borderRadius: 4, fontSize: 10,
          border: "1px solid var(--border)",
          color: created ? "var(--accent)" : "var(--text-dim)",
        }}
      >
        {processText(locale, created ? "output.created" : "output.modified")}
      </span>

      <span
        title={file.relPath}
        style={{
          flex: 1, minWidth: 0, fontSize: 12, color: "var(--text)",
          fontFamily: "var(--font-mono)", overflow: "hidden",
          textOverflow: "ellipsis", whiteSpace: "nowrap", direction: "rtl", textAlign: "left",
        }}
      >
        {file.relPath}
      </span>

      {hasDiff && (
        <span style={{ flexShrink: 0, fontSize: 11, color: "var(--text-dim)", fontVariantNumeric: "tabular-nums" }}>
          +{file.added ?? 0} {"\u2212"}{file.removed ?? 0}
        </span>
      )}

      <div style={{ display: "flex", alignItems: "center", gap: 2, flexShrink: 0 }}>
        {onOpenFile && (
          <button
            type="button"
            onClick={() => onOpenFile(file.path)}
            title={processText(locale, "output.view")}
            style={actionStyle}
          >
            {processText(locale, "output.view")}
          </button>
        )}
        <a
          href={`/api/files/${encodeFilePathForApi(file.path)}?type=download`}
          download={file.name}
          title={processText(locale, "output.download")}
          style={{ ...actionStyle, textDecoration: "none" }}
        >
          {processText(locale, "output.download")}
        </a>
        <button
          type="button"
          onClick={() => { copyPath(file.path).then((ok) => { if (ok) setCopied(true); setTimeout(() => setCopied(false), COPIED_MS); }); }}
          title={processText(locale, "output.copyPath")}
          style={{ ...actionStyle, color: copied ? "var(--accent)" : "var(--text-dim)" }}
        >
          {processText(locale, "output.copyPath")}
        </button>
      </div>
    </div>
  );
}

const actionStyle: React.CSSProperties = {
  padding: "2px 6px",
  border: "none",
  borderRadius: 4,
  background: "transparent",
  color: "var(--text-dim)",
  fontSize: 11,
  cursor: "pointer",
  whiteSpace: "nowrap",
};

/**
 * Render the turn's output files.
 * @param props The collected files and the host's file opener
 * @returns The card list, or null when the turn wrote nothing
 */
export function OutputFileCards({ files, onOpenFile, cwd, since, until, swept }: OutputFileCardsProps) {
  const { locale } = useI18n();
  const [showAll, setShowAll] = useState(false);

  const merged = useMemo(() => {
    if (!swept || swept.length === 0 || since === undefined || until === undefined) return files;
    // Each turn takes only the slice of the session sweep that falls inside its own window.
    const inWindow = swept.filter((hit) => hit.modifiedMs >= since && hit.modifiedMs <= until);
    if (inWindow.length === 0) return files;
    return mergeSweptOutputFiles(files, inWindow, { cwd, since });
  }, [files, swept, cwd, since, until]);

  if (merged.length === 0) return null;

  // The collector returns everything; capping is a rendering decision, so the "+n more"
  // count stays computable rather than being lost inside the pure function.
  const { visible, hiddenCount } = visibleOutputFiles(merged, showAll);

  return (
    <div style={{ margin: "2px 0 14px", minWidth: 0 }}>
      <div style={{ marginBottom: 6, fontSize: 11, color: "var(--text-dim)" }}>
        {processText(locale, "output.title", { count: merged.length })}
      </div>
      <div style={{ display: "grid", gap: 6, minWidth: 0 }}>
        {visible.map((file) => (
          <FileCard key={file.path} file={file} onOpenFile={onOpenFile} />
        ))}
      </div>
      {(hiddenCount > 0 || (showAll && merged.length > OUTPUT_FILE_PREVIEW_COUNT)) && (
        <button
          type="button"
          onClick={() => setShowAll((wasShowingAll) => !wasShowingAll)}
          style={{ ...actionStyle, marginTop: 6, padding: "2px 0" }}
        >
          {hiddenCount > 0
            ? processText(locale, "output.more", { count: hiddenCount })
            : processText(locale, "output.showFewer", { count: OUTPUT_FILE_PREVIEW_COUNT })}
        </button>
      )}
    </div>
  );
}
