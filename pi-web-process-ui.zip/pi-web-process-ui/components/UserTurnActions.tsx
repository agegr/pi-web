"use client";

/**
 * The action row under each user request: edit this request, fork it into an independent
 * session, and step between sibling branches when the request has been asked more than once.
 *
 * All three actions already exist in v0.8.7 — `onEditContent`, `handleFork`, and
 * `handleNavigate` — but they live inside `UserMessageView` in `components/MessageView.tsx`,
 * which this bundle leaves unmodified (PLAN.md §1.3). This renders them as labelled controls
 * next to the request instead, so they are discoverable rather than hidden.
 */

import { useI18n } from "@/hooks/useI18n";
import { processText } from "@/lib/process-ui-text";

export interface BranchPosition {
  /** 1-based position among siblings, so the label reads "1/2" not "0/2". */
  index: number;
  total: number;
  /** Entry ids of the sibling requests, in order. */
  siblingEntryIds: string[];
}

export interface UserTurnActionsProps {
  /** Switches the conversation to a sibling branch. */
  onNavigate?: (entryId: string) => void;
  /** Present only when this request has siblings. */
  branch?: BranchPosition;
  /** Disables every action while the agent is working. */
  disabled?: boolean;
}

const BUTTON_STYLE: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 4,
  padding: "2px 6px",
  border: "none",
  borderRadius: 4,
  background: "transparent",
  color: "var(--text-dim)",
  fontSize: 11,
  cursor: "pointer",
};

/**
 * Render the action row for one user request.
 * @param props The request, its entry id, and the handlers ChatWindow already owns
 * @returns The action row, or null when nothing is actionable
 */
export function UserTurnActions({
  onNavigate, branch, disabled = false,
}: UserTurnActionsProps) {
  const { locale } = useI18n();

  const canNavigate = Boolean(onNavigate && branch && branch.total > 1) && !disabled;
  // Nothing to switch between means nothing to show. The Copy / Edit from here / New session
  // row is MessageView's own and is left alone — duplicating it put two rows of the same
  // buttons under every request.
  if (!canNavigate) return null;

  // Deliberately does NOT wrap. "<" means go back to the version before the edit and ">"
  // means go forward to the edited one; wrapping would make "<" on 1/2 jump forward, which
  // reads as the arrow doing the opposite of what it says.
  const canGoBack = Boolean(branch && branch.index > 1);
  const canGoForward = Boolean(branch && branch.index < branch.total);
  const goToSibling = (offset: number) => {
    if (!branch || !onNavigate) return;
    const nextIndex = branch.index - 1 + offset;
    if (nextIndex < 0 || nextIndex >= branch.total) return;
    const target = branch.siblingEntryIds[nextIndex];
    if (target) onNavigate(target);
  };

  const disabledStyle = (enabled: boolean): React.CSSProperties =>
    enabled ? {} : { opacity: 0.4, cursor: "default" };

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 2, justifyContent: "flex-end", margin: "2px 0 10px" }}>
      {branch && branch.total > 1 && (
        <div style={{ display: "flex", alignItems: "center", gap: 2, marginRight: 4 }}>
          <button
            type="button"
            onClick={() => goToSibling(-1)}
            disabled={!canNavigate || !canGoBack}
            title={processText(locale, "turn.prevBranch")}
            aria-label={processText(locale, "turn.prevBranch")}
            style={{ ...BUTTON_STYLE, padding: "2px 4px", ...disabledStyle(canNavigate && canGoBack) }}
          >
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 18l-6-6 6-6" />
            </svg>
          </button>
          <span style={{ fontSize: 11, color: "var(--text-dim)", fontVariantNumeric: "tabular-nums", minWidth: 26, textAlign: "center" }}>
            {branch.index}/{branch.total}
          </span>
          <button
            type="button"
            onClick={() => goToSibling(1)}
            disabled={!canNavigate || !canGoForward}
            title={processText(locale, "turn.nextBranch")}
            aria-label={processText(locale, "turn.nextBranch")}
            style={{ ...BUTTON_STYLE, padding: "2px 4px", ...disabledStyle(canNavigate && canGoForward) }}
          >
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M9 18l6-6-6-6" />
            </svg>
          </button>
        </div>
      )}

    </div>
  );
}
