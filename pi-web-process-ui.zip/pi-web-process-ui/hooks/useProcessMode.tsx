"use client";

/**
 * Global "how much process do I want to see" setting, persisted to localStorage.
 *
 * DEVIATION FROM PLAN.md §5, which specifies a React context provider. A provider has to be
 * mounted above every consumer, and the only file that sits above both the AppShell top bar
 * and ChatWindow is `AppShell.tsx` — a 1,662-line file this bundle already replaces. Adding
 * a wrapper there means editing its root JSX fragment, and in a whole-file drop-in every
 * extra edit to a replaced file is a chance to lose something silently (PLAN.md §1.1).
 *
 * A module-level store read through `useSyncExternalStore` gives the same shared state with
 * zero extra edits to `AppShell.tsx`, and it solves the hydration problem PLAN.md §5 warns
 * about more directly: `getServerSnapshot` returns the default, the client reads
 * localStorage in an effect afterwards, so server and first client render always agree.
 *
 * Storage key `pi-process-mode`, following the `pi-sound-enabled` pattern in `useAudio.ts`.
 */

import { useCallback, useEffect, useSyncExternalStore } from "react";

export type ProcessMode = "expanded" | "collapsed" | "hidden";

const STORAGE_KEY = "pi-process-mode";
const DEFAULT_MODE: ProcessMode = "collapsed";
/**
 * Cycle order for the shortcut and the top-bar button.
 *
 * Only compact and hidden. "expanded" stays in the ProcessMode type and is still reachable
 * per turn by clicking a timeline header, but it is not part of the global cycle: expanding
 * every turn at once buries the answers, which is the thing this UI exists to surface.
 */
const MODE_CYCLE: ProcessMode[] = ["collapsed", "hidden"];

function isProcessMode(value: unknown): value is ProcessMode {
  return value === "expanded" || value === "collapsed" || value === "hidden";
}

let currentMode: ProcessMode = DEFAULT_MODE;
let hydrated = false;
const listeners = new Set<() => void>();

function emit(): void {
  for (const listener of listeners) listener();
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot(): ProcessMode {
  return currentMode;
}

/**
 * Server render always sees the default. The stored value is applied on the client after
 * mount, so the first client render matches the server and React never reports a mismatch.
 */
function getServerSnapshot(): ProcessMode {
  return DEFAULT_MODE;
}

/**
 * Set the global process mode and persist it.
 * @param mode The new mode
 */
export function setProcessMode(mode: ProcessMode): void {
  if (currentMode === mode) return;
  currentMode = mode;
  try {
    window.localStorage.setItem(STORAGE_KEY, mode);
  } catch {
    // Private mode or storage disabled — the setting stays in memory for this session.
  }
  emit();
}

/**
 * Advance to the next mode in the cycle.
 * @returns The mode that is now active
 */
export function cycleProcessMode(): ProcessMode {
  // indexOf returns -1 for "expanded" (restored from an older stored value), which lands on
  // index 0 — "collapsed". That is the right first stop out of an off-cycle mode.
  const next = MODE_CYCLE[(MODE_CYCLE.indexOf(currentMode) + 1) % MODE_CYCLE.length];
  setProcessMode(next);
  return next;
}

/** Read the stored value once, on the client, after the first render. */
function hydrateFromStorage(): void {
  if (hydrated) return;
  hydrated = true;
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (isProcessMode(stored) && stored !== currentMode) {
      currentMode = stored;
      emit();
    }
  } catch {
    // Ignore — the default is a fine fallback.
  }
}

/**
 * True when a keystroke should be left alone because the user is typing.
 * @param target The event target
 */
function isTextEntryTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  const tag = target.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target.isContentEditable;
}

let shortcutBound = false;

/**
 * Bind Ctrl/Cmd + Shift + H once per document.
 *
 * The drop-in does not replace `hooks/useKeyboardShortcuts.ts`, so the listener is
 * registered here instead, exactly as PLAN.md §5 prescribes.
 */
function bindShortcut(): void {
  if (shortcutBound || typeof document === "undefined") return;
  shortcutBound = true;
  document.addEventListener("keydown", (event) => {
    if (!event.shiftKey || !(event.ctrlKey || event.metaKey)) return;
    if (event.key.toLowerCase() !== "h") return;
    if (isTextEntryTarget(event.target)) return;
    event.preventDefault();
    cycleProcessMode();
  });
}

export interface ProcessModeApi {
  mode: ProcessMode;
  setMode: (mode: ProcessMode) => void;
  cycleMode: () => void;
}

/**
 * Read and write the global process mode.
 * @returns The active mode plus setters, stable across renders
 */
export function useProcessMode(): ProcessModeApi {
  const mode = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  useEffect(() => {
    hydrateFromStorage();
    bindShortcut();
  }, []);

  const setMode = useCallback((next: ProcessMode) => setProcessMode(next), []);
  const cycleMode = useCallback(() => {
    cycleProcessMode();
  }, []);

  return { mode, setMode, cycleMode };
}

/**
 * The i18n key describing a mode, for the top-bar control's label and tooltip.
 * @param mode The mode to describe
 * @returns A key from `lib/process-ui-text.ts`
 */
export function processModeTextKey(mode: ProcessMode): string {
  if (mode === "expanded") return "process.modeExpanded";
  if (mode === "hidden") return "process.modeHidden";
  return "process.modeCollapsed";
}
