import assert from "node:assert/strict";
import test from "node:test";
import { createJiti } from "jiti";

const jiti = createJiti(import.meta.url, { tsconfigPaths: true });
const { setProcessMode, cycleProcessMode, processModeTextKey } =
  await jiti.import("./useProcessMode.tsx");

test("the cycle only visits compact and hidden", () => {
  setProcessMode("collapsed");
  const seen = [cycleProcessMode(), cycleProcessMode(), cycleProcessMode(), cycleProcessMode()];
  assert.deepEqual(seen, ["hidden", "collapsed", "hidden", "collapsed"]);
});

test("expanded is never reached by the shortcut", () => {
  setProcessMode("collapsed");
  for (let i = 0; i < 10; i += 1) {
    assert.notEqual(cycleProcessMode(), "expanded");
  }
});

test("an off-cycle mode lands on compact", () => {
  // "expanded" can still arrive from a per-turn click or a value stored by an older build.
  setProcessMode("expanded");
  assert.equal(cycleProcessMode(), "collapsed");
});

test("each mode maps to its own label key", () => {
  assert.equal(processModeTextKey("expanded"), "process.modeExpanded");
  assert.equal(processModeTextKey("collapsed"), "process.modeCollapsed");
  assert.equal(processModeTextKey("hidden"), "process.modeHidden");
});
