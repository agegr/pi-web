import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { getAllowedFileRoots, isFilePathAllowed } from "@/lib/file-access";
import { isApiRequestAllowed } from "@/lib/request-security";

/**
 * Lists files under a working directory whose mtime falls inside a window.
 *
 * This exists to catch writes the tool-call record misses — anything a bash command produced
 * with `>`, `tee`, `mv`, or a script it ran. `lib/output-files.ts` deliberately never parses
 * bash, because guessing at shell redirection produces more wrong answers than value; asking
 * the filesystem what actually changed is the honest way to cover that gap.
 *
 * SECURITY: this walks a directory tree, so it reuses the exact guards
 * `app/api/files/[...path]/route.ts` uses — `isApiRequestAllowed`, `getAllowedFileRoots` +
 * `isFilePathAllowed`, and a `realpathSync` check on both the requested root and every
 * directory it descends into, so a symlink inside an allowed root cannot walk out of it.
 */

/** Directories never worth reporting: build output, vendored code, VCS internals, caches. */
const EXCLUDED_DIRS = new Set([
  "node_modules", ".git", "dist", ".next", "build", "out", "coverage",
  ".turbo", ".cache", ".venv", "venv", "__pycache__", ".pytest_cache",
  ".idea", ".vscode", ".gradle", "target", "vendor",
]);

/** Editor scratch and lock files that change constantly and mean nothing to the user. */
const EXCLUDED_SUFFIXES = [".swp", ".swo", ".tmp", ".temp", ".lock", "~", ".pyc", ".log"];

/** Bounds, so a sweep of a large repo cannot stall the request. */
const MAX_DEPTH = 8;
const MAX_ENTRIES_SCANNED = 20000;
const MAX_RESULTS = 200;
/**
 * Wall-clock budget. A monorepo can hold far more than MAX_ENTRIES_SCANNED reachable files,
 * and a sweep that runs for a second blocks every other request on this server. Returning a
 * partial answer quickly beats a complete one slowly — the cards are a convenience, and the
 * tool-derived entries are already on screen by the time this returns.
 */
const TIME_BUDGET_MS = 400;

interface SweepHit {
  path: string;
  modifiedMs: number;
  /**
   * Creation time, so the client can say "New" instead of "Changed" for a file that did not
   * exist before the turn. Not every filesystem records this faithfully, so the client treats
   * a birthtime outside the window as "unknown" and falls back to the weaker claim.
   */
  createdMs: number;
  size: number;
}

/**
 * Whether a directory entry should be skipped outright.
 * @param name The entry's base name
 * @param isDir Whether it is a directory
 */
function isExcluded(name: string, isDir: boolean): boolean {
  if (isDir) return EXCLUDED_DIRS.has(name) || name.startsWith(".");
  if (name.startsWith(".")) return true;
  return EXCLUDED_SUFFIXES.some((suffix) => name.endsWith(suffix));
}

/**
 * Walk a directory collecting files modified inside the window.
 * @param root The real, allowed root to stay inside
 * @param dir Directory currently being scanned
 * @param since Window start, epoch ms
 * @param until Window end, epoch ms
 * @param depth Remaining descent budget
 * @param state Mutable counters shared across the walk
 * @param hits Output accumulator
 */
function sweep(
  root: string,
  dir: string,
  since: number,
  until: number,
  depth: number,
  state: { scanned: number; deadline: number },
  hits: SweepHit[],
): void {
  if (depth < 0 || hits.length >= MAX_RESULTS || state.scanned >= MAX_ENTRIES_SCANNED) return;
  if (Date.now() > state.deadline) return;

  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return; // Unreadable directory — skip rather than fail the whole sweep.
  }

  for (const entry of entries) {
    if (hits.length >= MAX_RESULTS || state.scanned >= MAX_ENTRIES_SCANNED) return;
    state.scanned += 1;

    const isDir = entry.isDirectory();
    if (isExcluded(entry.name, isDir)) continue;

    const full = path.join(dir, entry.name);

    // A symlink inside an allowed root must not be followed out of it — but only symlinks
    // can leave, and readdir already told us which entries are symlinks. Resolving every
    // entry cost one extra syscall per file for nothing: on a 6,000 file tree that was
    // 173ms versus 30ms. The security property is identical; the work is not.
    if (entry.isSymbolicLink()) {
      let real: string;
      try {
        real = fs.realpathSync(full);
      } catch {
        continue;
      }
      if (!real.startsWith(root + path.sep) && real !== root) continue;
    }

    if (isDir) {
      sweep(root, full, since, until, depth - 1, state, hits);
      continue;
    }
    // Only regular files. A symlink to a file was already bounds-checked above.
    if (!entry.isFile() && !entry.isSymbolicLink()) continue;

    let stat: fs.Stats;
    try {
      stat = fs.statSync(full);
    } catch {
      continue;
    }
    if (stat.mtimeMs < since || stat.mtimeMs > until) continue;

    hits.push({
      path: full.split(path.sep).join("/"),
      modifiedMs: stat.mtimeMs,
      createdMs: stat.birthtimeMs,
      size: stat.size,
    });
  }
}

/**
 * GET /api/output-files?cwd=&since=&until=
 * @returns Files under cwd modified within [since, until]
 */
export async function GET(request: NextRequest) {
  if (!isApiRequestAllowed(request)) {
    return NextResponse.json({ error: "Untrusted API request" }, { status: 403 });
  }

  const params = request.nextUrl.searchParams;
  const cwd = params.get("cwd");
  const since = Number(params.get("since"));
  const until = Number(params.get("until"));

  if (!cwd || !Number.isFinite(since) || !Number.isFinite(until) || until < since) {
    return NextResponse.json({ error: "Invalid window" }, { status: 400 });
  }

  const allowedRoots = await getAllowedFileRoots();
  if (!isFilePathAllowed(cwd, allowedRoots)) {
    return NextResponse.json({ error: "Access denied" }, { status: 403 });
  }

  let root: string;
  try {
    root = fs.realpathSync(cwd);
  } catch {
    return NextResponse.json({ error: "Directory not found" }, { status: 404 });
  }

  const realRoots = new Set<string>();
  for (const allowed of allowedRoots) {
    try {
      realRoots.add(fs.realpathSync(allowed));
    } catch {
      // Ignore stale roots that no longer exist.
    }
  }
  if (!isFilePathAllowed(root, realRoots)) {
    return NextResponse.json({ error: "Access denied" }, { status: 403 });
  }

  const hits: SweepHit[] = [];
  const state = { scanned: 0, deadline: Date.now() + TIME_BUDGET_MS };
  sweep(root, root, since, until, MAX_DEPTH, state, hits);
  hits.sort((a, b) => b.modifiedMs - a.modifiedMs);

  return NextResponse.json({
    files: hits,
    truncated: hits.length >= MAX_RESULTS || state.scanned >= MAX_ENTRIES_SCANNED || Date.now() > state.deadline,
  });
}
